import os
import sys
from ..local_aggregation_operators import LocalAggregation,LocalAggregation_Ori
import  torch
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(os.path.dirname(BASE_DIR))
sys.path.append(ROOT_DIR)
sys.path.append(os.path.join(ROOT_DIR, 'ops', 'pt_custom_ops'))
import torch.nn.functional as F

import torch.nn as nn
from pt_utils import MaskedMaxPool


class MultiInputSequential(nn.Sequential):

    def forward(self, *input):
        for module in self._modules.values():
            input = module(*input)
        return input





class Bottleneck(nn.Module):
    def __init__(self, in_channels, out_channels, bottleneck_ratio, radius, nsample, config,
                 downsample=False, sampleDl=None, npoint=None, trans=None):
        super(Bottleneck, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.downsample = downsample
        self.conf = config
        if downsample:
            self.maxpool = MaskedMaxPool(npoint, radius, nsample, sampleDl)

        self.conv1 = nn.Sequential(nn.Conv1d(in_channels, out_channels // bottleneck_ratio, kernel_size=1, bias=False),
                                   nn.BatchNorm1d(out_channels // bottleneck_ratio, momentum=config.bn_momentum),
                                   nn.ReLU(inplace=True))

        self.local_aggregation = LocalAggregation(out_channels // bottleneck_ratio,
                                                      out_channels // bottleneck_ratio,
                                                      radius, nsample, config, None)

        self.conv2 = nn.Sequential(nn.Conv1d(out_channels // bottleneck_ratio, out_channels, kernel_size=1, bias=False),
                                   nn.BatchNorm1d(out_channels, momentum=config.bn_momentum))
        self.relu = nn.ReLU(inplace=True)

        if in_channels != out_channels:
            self.shortcut = nn.Sequential(
                nn.Conv1d(in_channels, out_channels, kernel_size=1, bias=False),
                nn.BatchNorm1d(out_channels, momentum=config.bn_momentum))

    def forward(self, xyz, mask, features):
        if self.downsample:
            sub_xyz, sub_mask, sub_features = self.maxpool(xyz, mask, features)
            query_xyz = sub_xyz
            query_mask = sub_mask
            identity = sub_features
        else:
            query_xyz = xyz
            query_mask = mask
            identity = features

        output = self.conv1(features)
        if  (self.conf.local_aggregation_type.find('lrf')>=0): #   self.conf.local_aggregation_type == 'pointwisemlp_lrf' or self.conf.local_aggregation_type == 'pospool_lrf':
          output,  trans, var = self.local_aggregation(query_xyz, xyz, query_mask, mask, output)
        else:
            output = self.local_aggregation(query_xyz, xyz, query_mask, mask, output)
        output = self.conv2(output)

        if self.in_channels != self.out_channels:
            identity = self.shortcut(identity)

        output += identity
        output = self.relu(output)

        if  (self.conf.local_aggregation_type.find('lrf')>=0): #self.conf.local_aggregation_type == 'pointwisemlp_lrf' or self.conf.local_aggregation_type == 'pospool_lrf':
            return query_xyz, query_mask, output, trans, var
        else:
            return query_xyz, query_mask, output

    def forward_first(self, xyz, mask, features):
        if self.downsample:
            sub_xyz, sub_mask, sub_features = self.maxpool(xyz, mask, features)
            query_xyz = sub_xyz
            query_mask = sub_mask
            identity = sub_features
        else:
            query_xyz = xyz
            query_mask = mask
            identity = features

        # print("feature shape")
        # print(features.shape)

        output = self.conv1(features)
        diffFeatureNorm, nsample, aggregation_features, neighborhood_mask = self.local_aggregation.local_aggregation_operator.forward_firstpapss(query_xyz, xyz, query_mask, mask, output)
        return  diffFeatureNorm, nsample, aggregation_features, neighborhood_mask,identity, query_xyz, query_mask



    def forward_second(self, query_mask, learnTrans, diffFeatureNorm, weight, aggregation_features,neighborhood_mask,identity):

        output, var = self.local_aggregation.local_aggregation_operator.forward_secondpapss(query_mask, learnTrans, diffFeatureNorm, weight, aggregation_features,neighborhood_mask)
        output = self.conv2(output)

        if self.in_channels != self.out_channels:
            identity = self.shortcut(identity)

        output += identity
        output = self.relu(output)

        return output,  var


class Bottleneck_Ori(nn.Module):
    def __init__(self, in_channels, out_channels, bottleneck_ratio, radius, nsample, config,
                 downsample=False, sampleDl=None, npoint=None, trans=None):
        super(Bottleneck_Ori, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.downsample = downsample
        self.conf = config
        if downsample:
            self.maxpool = MaskedMaxPool(npoint, radius, nsample, sampleDl)

        self.conv1 = nn.Sequential(nn.Conv1d(in_channels, out_channels // bottleneck_ratio, kernel_size=1, bias=False),
                                   nn.BatchNorm1d(out_channels // bottleneck_ratio, momentum=config.bn_momentum),
                                   nn.ReLU(inplace=True))

        self.local_aggregation = LocalAggregation_Ori(out_channels // bottleneck_ratio,
                                                      out_channels // bottleneck_ratio,
                                                      radius, nsample, config)

        self.conv2 = nn.Sequential(nn.Conv1d(out_channels // bottleneck_ratio, out_channels, kernel_size=1, bias=False),
                                   nn.BatchNorm1d(out_channels, momentum=config.bn_momentum))
        self.relu = nn.ReLU(inplace=True)

        if in_channels != out_channels:
            self.shortcut = nn.Sequential(
                nn.Conv1d(in_channels, out_channels, kernel_size=1, bias=False),
                nn.BatchNorm1d(out_channels, momentum=config.bn_momentum))

    def forward(self, xyz, mask, features):
        if self.downsample:
            sub_xyz, sub_mask, sub_features = self.maxpool(xyz, mask, features)
            query_xyz = sub_xyz
            query_mask = sub_mask
            identity = sub_features
        else:
            query_xyz = xyz
            query_mask = mask
            identity = features

        output = self.conv1(features)
        output = self.local_aggregation(query_xyz, xyz, query_mask, mask, output)
        output = self.conv2(output)

        if self.in_channels != self.out_channels:
            identity = self.shortcut(identity)

        output += identity
        output = self.relu(output)

        return query_xyz, query_mask, output

class TNetWithMask(nn.Module):

	def __init__(self,  K=3):
		# Call the super constructor
		super(TNetWithMask, self).__init__()

		# Number of dimensions of the data
		self.K = K

		# Size of input
		# self.N = num_points

		# Initialize identity matrix on the GPU (do this here so it only
		# happens once)
		self.identity = torch.autograd.Variable(
			torch.eye(self.K).float().view(-1))

		# First embedding block
		self.block1 =nn.Sequential(
			nn.Conv1d(K, 64, 1),
			nn.BatchNorm1d(64),
			nn.ReLU())

		# Second embedding block
		self.block2 =nn.Sequential(
			nn.Conv1d(64, 128, 1),
			nn.BatchNorm1d(128),
			nn.ReLU())

		# Third embedding block
		self.block3 =nn.Sequential(
			nn.Conv1d(128, 128, 1),
			nn.BatchNorm1d(128),
			nn.ReLU())

		# Multilayer perceptron
		self.mlp = nn.Sequential(
			nn.Linear(128, 128),
			nn.BatchNorm1d(128),
			nn.ReLU(),
			nn.Linear(128, 64),
			nn.BatchNorm1d(64),
			nn.ReLU(),
			nn.Linear(64, K * K))

		self.mlp2 = nn.Sequential(
			nn.Linear(128, 16),
			nn.BatchNorm1d(16),
			nn.ReLU(),
			nn.Linear(16, 1),
			nn.Sigmoid())


	# Take as input a B x K x N matrix of B batches of N points with K
	# dimensions
	def forward(self, x, N):

		# Compute the feature extractions
		# Output should ultimately be B x 1024 x N
		x = self.block1(x)
		x = self.block2(x)
		x = self.block3(x)

		# Pool over the number of points
		# Output should be B x 1024 x 1 --> B x 1024 (after squeeze)
		x = F.max_pool1d(x, N).squeeze(2)

		# Run the pooled features through the multi-layer perceptron
		# Output should be B x K^2
		mask = self.mlp2(x)

		x = self.mlp(x)

		# Add identity matrix to transform
		# Output is still B x K^2 (broadcasting takes care of batch dimension)
		x += self.identity.cuda()

		# Reshape the output into B x K x K affine transformation matrices
		x = x.view(-1, self.K, self.K)

		return x, mask


# class TNetWithMask(nn.Module):
#
# 	def __init__(self,  K=3):
# 		# Call the super constructor
# 		super(TNetWithMask, self).__init__()
#
# 		# Number of dimensions of the data
# 		self.K = K
#
# 		# Size of input
# 		# self.N = num_points
#
# 		# Initialize identity matrix on the GPU (do this here so it only
# 		# happens once)
# 		self.identity = torch.autograd.Variable(
# 			torch.eye(self.K).float().view(-1))
#
# 		# First embedding block
# 		self.block1 =nn.Sequential(
# 			nn.Conv1d(K, 64, 1),
# 			nn.BatchNorm1d(64),
# 			nn.ReLU())
#
# 		# Second embedding block
# 		self.block2 =nn.Sequential(
# 			nn.Conv1d(64, 128, 1),
# 			nn.BatchNorm1d(128),
# 			nn.ReLU())
#
# 		# Third embedding block
# 		self.block3 =nn.Sequential(
# 			nn.Conv1d(128, 1024, 1),
# 			nn.BatchNorm1d(1024),
# 			nn.ReLU())
#
# 		# Multilayer perceptron
# 		self.mlp = nn.Sequential(
# 			nn.Linear(1024, 512),
# 			nn.BatchNorm1d(512),
# 			nn.ReLU(),
# 			nn.Linear(512, 256),
# 			nn.BatchNorm1d(256),
# 			nn.ReLU(),
# 			nn.Linear(256, K * K))
#
# 		self.mlp2 = nn.Sequential(
# 			nn.Linear(1024, 64),
# 			nn.BatchNorm1d(64),
# 			nn.ReLU(),
# 			nn.Linear(64, 1),
# 			nn.Sigmoid())
#
# 	# Take as input a B x K x N matrix of B batches of N points with K
# 	# dimensions
# 	def forward(self, x, N):
#
# 		# Compute the feature extractions
# 		# Output should ultimately be B x 1024 x N
# 		x = self.block1(x)
# 		x = self.block2(x)
# 		x = self.block3(x)
#
# 		# Pool over the number of points
# 		# Output should be B x 1024 x 1 --> B x 1024 (after squeeze)
# 		x = F.max_pool1d(x, N).squeeze(2)
#
# 		# Run the pooled features through the multi-layer perceptron
# 		# Output should be B x K^2
# 		mask = self.mlp2(x)
#
# 		x = self.mlp(x)
#
# 		# Add identity matrix to transform
# 		# Output is still B x K^2 (broadcasting takes care of batch dimension)
# 		x += self.identity.cuda()
#
# 		# Reshape the output into B x K x K affine transformation matrices
# 		x = x.view(-1, self.K, self.K)
#
# 		return x, mask


class ResNet(nn.Module):
    def __init__(self, config, input_features_dim, radius, sampleDl, nsamples, npoints,
                 width=144, depth=2, bottleneck_ratio=2):
        """Resnet Backbone

        Args:
            config: config file.
            input_features_dim: dimension for input feature.
            radius: the base ball query radius.
            sampleDl: the base grid length for sub-sampling.
            nsamples: neighborhood limits for each layer, a List of int.
            npoints: number of points after each sub-sampling, a list of int.
            width: the base channel num.
            depth: number of bottlenecks in one stage.
            bottleneck_ratio: bottleneck ratio.

        Returns:
            A dict of points, masks, features for each layer.
        """
        super(ResNet, self).__init__()

        self.input_features_dim = input_features_dim

        self.conv1 = nn.Sequential(nn.Conv1d(input_features_dim, width // 2, kernel_size=1, bias=False),
                                   nn.BatchNorm1d(width // 2, momentum=config.bn_momentum),
                                   nn.ReLU(inplace=True))
        self.trans = TNetWithMask()

        self.la1 = LocalAggregation_Ori(width // 2, width // 2, radius, nsamples[0], config)
        self.btnk1 = Bottleneck(width // 2, width, bottleneck_ratio, radius, nsamples[0], config)

        if   (config.local_aggregation_type.find('lrf')>=0):  # == 'pointwisemlp_lrf' or config.local_aggregation_type == 'pospool_lrf' :
            self.layer1 = nn.Sequential()
            sampleDl *= 2
            self.layer1.add_module("strided_bottleneck",
                                   Bottleneck(width, 2 * width, bottleneck_ratio, radius, nsamples[0], config, trans=None,
                                              downsample=True, sampleDl=sampleDl, npoint=npoints[0]))
            radius *= 2
            width *= 2
            for i in range(depth - 1):
                self.layer1.add_module(f"bottlneck{i}",
                                       Bottleneck(width, width, bottleneck_ratio, radius, nsamples[1], config,trans=None))

            self.layer2 = nn.Sequential()
            sampleDl *= 2
            self.layer2.add_module("strided_bottleneck",
                                   Bottleneck(width, 2 * width, bottleneck_ratio, radius, nsamples[1], config,trans=None,
                                              downsample=True, sampleDl=sampleDl, npoint=npoints[1]))
            radius *= 2
            width *= 2
            for i in range(depth - 1):
                self.layer2.add_module(f"bottlneck{i}",
                                       Bottleneck(width, width, bottleneck_ratio, radius, nsamples[2], config,trans=None))

            self.layer3 = nn.Sequential()
            sampleDl *= 2
            self.layer3.add_module("strided_bottleneck",
                                   Bottleneck(width, 2 * width, bottleneck_ratio, radius, nsamples[2], config,trans=None,
                                              downsample=True, sampleDl=sampleDl, npoint=npoints[2]))
            radius *= 2
            width *= 2
            for i in range(depth - 1):
                self.layer3.add_module(f"bottlneck{i}",
                                       Bottleneck(width, width, bottleneck_ratio, radius, nsamples[3], config,trans=None))

            self.layer4 = nn.Sequential()
            sampleDl *= 2
            self.layer4.add_module("strided_bottleneck",
                                   Bottleneck(width, 2 * width, bottleneck_ratio, radius, nsamples[3], config,trans=None,
                                              downsample=True, sampleDl=sampleDl, npoint=npoints[3]))
            radius *= 2
            width *= 2
            for i in range(depth - 1):
                self.layer4.add_module(f"bottlneck{i}",
                                       Bottleneck(width, width, bottleneck_ratio, radius, nsamples[4], config,trans=None))

        else:

            self.layer1 = MultiInputSequential()
            sampleDl *= 2
            self.layer1.add_module("strided_bottleneck",
                                   Bottleneck(width, 2 * width, bottleneck_ratio, radius, nsamples[0], config, trans=self.trans,
                                              downsample=True, sampleDl=sampleDl, npoint=npoints[0]))
            radius *= 2
            width *= 2
            for i in range(depth - 1):
                self.layer1.add_module(f"bottlneck{i}",
                                       Bottleneck(width, width, bottleneck_ratio, radius, nsamples[1], config,trans=self.trans))

            self.layer2 = MultiInputSequential()
            sampleDl *= 2
            self.layer2.add_module("strided_bottleneck",
                                   Bottleneck(width, 2 * width, bottleneck_ratio, radius, nsamples[1], config,trans=self.trans,
                                              downsample=True, sampleDl=sampleDl, npoint=npoints[1]))
            radius *= 2
            width *= 2
            for i in range(depth - 1):
                self.layer2.add_module(f"bottlneck{i}",
                                       Bottleneck(width, width, bottleneck_ratio, radius, nsamples[2], config,trans=self.trans))

            self.layer3 = MultiInputSequential()
            sampleDl *= 2
            self.layer3.add_module("strided_bottleneck",
                                   Bottleneck(width, 2 * width, bottleneck_ratio, radius, nsamples[2], config,trans=self.trans,
                                              downsample=True, sampleDl=sampleDl, npoint=npoints[2]))
            radius *= 2
            width *= 2
            for i in range(depth - 1):
                self.layer3.add_module(f"bottlneck{i}",
                                       Bottleneck(width, width, bottleneck_ratio, radius, nsamples[3], config,trans=self.trans))

            self.layer4 = MultiInputSequential()
            sampleDl *= 2
            self.layer4.add_module("strided_bottleneck",
                                   Bottleneck(width, 2 * width, bottleneck_ratio, radius, nsamples[3], config,trans=self.trans,
                                              downsample=True, sampleDl=sampleDl, npoint=npoints[3]))
            radius *= 2
            width *= 2
            for i in range(depth - 1):
                self.layer4.add_module(f"bottlneck{i}",
                                       Bottleneck(width, width, bottleneck_ratio, radius, nsamples[4], config,trans=self.trans))

        self.conf = config

    def forward(self, xyz, mask, features, end_points=None):
        """
        Args:
            xyz: (B, N, 3), point coordinates
            mask: (B, N), 0/1 mask to distinguish padding points1
            features: (B, 3, input_features_dim), input points features.
            end_points: a dict

        Returns:
            end_points: a dict contains all outputs
        """
        if not end_points: end_points = {}
        # res1
        features = self.conv1(features)

        if (self.conf.local_aggregation_type.find('lrf')>=0):  #  self.conf.local_aggregation_type == 'pointwisemlp_lrf' or self.conf.local_aggregation_type == 'pospool_lrf':
            trans=[]
            vars=[]

            features = self.la1(xyz, xyz, mask, mask, features)
            # features, trans0, var0 = self.la1(xyz, xyz, mask, mask, features)

            diffFeatureNorm, nsample, aggregation_features, neighborhood_mask,identity, xyz, mask = self.btnk1.forward_first(xyz, mask, features)
            learnTrans, weight = self.trans(diffFeatureNorm.permute(0,2,1), nsample)
            features,  var = self.btnk1.forward_second(mask, learnTrans, diffFeatureNorm, weight, aggregation_features,neighborhood_mask,identity)
            trans.append(learnTrans)
            vars.append(var)
            # xyz, mask, features, trans1, var1 = self.btnk1(xyz, mask, features)
            # xyz, mask, features = self.btnk1(xyz, mask, features)

            end_points['res1_xyz'] = xyz
            end_points['res1_mask'] = mask
            end_points['res1_features'] = features


            for module in self.layer1._modules.values():
                # xyz, mask, features, trans2, var2 = module(xyz, mask, features)
                diffFeatureNorm, nsample, aggregation_features, neighborhood_mask,identity, xyz, mask = module.forward_first(xyz, mask, features)
                learnTrans, weight = self.trans(diffFeatureNorm.permute(0,2,1), nsample)
                features,  var = module.forward_second(mask, learnTrans, diffFeatureNorm, weight, aggregation_features,neighborhood_mask,identity)
                trans.append(learnTrans)
                vars.append(var)

            end_points['res2_xyz'] = xyz
            end_points['res2_mask'] = mask
            end_points['res2_features'] = features

            # res3
            for module in self.layer2._modules.values():
                # xyz, mask, features = module(xyz, mask, features)
                diffFeatureNorm, nsample, aggregation_features, neighborhood_mask,identity, xyz, mask = module.forward_first(xyz, mask, features)
                learnTrans, weight = self.trans(diffFeatureNorm.permute(0,2,1), nsample)
                features,  var = module.forward_second(mask, learnTrans, diffFeatureNorm, weight, aggregation_features,neighborhood_mask,identity)
                trans.append(learnTrans)
                vars.append(var)
                # xyz, mask, features, trans3, var3 = module(xyz, mask, features)
                # trans.append(trans3)
                # vars.append(var3)
            end_points['res3_xyz'] = xyz
            end_points['res3_mask'] = mask
            end_points['res3_features'] = features

            # res4
            for module in self.layer3._modules.values():
                # xyz, mask, features = module(xyz, mask, features)
                diffFeatureNorm, nsample, aggregation_features, neighborhood_mask,identity, xyz, mask = module.forward_first(xyz, mask, features)
                learnTrans, weight = self.trans(diffFeatureNorm.permute(0,2,1), nsample)
                features,  var = module.forward_second(mask, learnTrans, diffFeatureNorm, weight, aggregation_features,neighborhood_mask,identity)
                trans.append(learnTrans)
                vars.append(var)
                # xyz, mask, features, trans3, var3 = module(xyz, mask, features)
                # trans.append(trans3)
                # vars.append(var3)
            end_points['res4_xyz'] = xyz
            end_points['res4_mask'] = mask
            end_points['res4_features'] = features

            # res5
            for module in self.layer4._modules.values():
                # xyz, mask, features = module(xyz, mask, features)
                diffFeatureNorm, nsample, aggregation_features, neighborhood_mask,identity, xyz, mask = module.forward_first(xyz, mask, features)
                learnTrans, weight = self.trans(diffFeatureNorm.permute(0,2,1), nsample)
                features,  var = module.forward_second(mask, learnTrans, diffFeatureNorm, weight, aggregation_features,neighborhood_mask,identity)
                trans.append(learnTrans)
                vars.append(var)
                # xyz, mask, features, trans3, var3 = module(xyz, mask, features)
                # trans.append(trans3)
                # vars.append(var3)

            end_points['res5_xyz'] = xyz
            end_points['res5_mask'] = mask
            end_points['res5_features'] = features

            return end_points,  trans, vars


        else:
            features = self.la1(xyz, xyz, mask, mask, features)
            xyz, mask, features = self.btnk1(xyz, mask, features)
            end_points['res1_xyz'] = xyz
            end_points['res1_mask'] = mask
            end_points['res1_features'] = features

            # res2
            xyz, mask, features = self.layer1(xyz, mask, features)
            end_points['res2_xyz'] = xyz
            end_points['res2_mask'] = mask
            end_points['res2_features'] = features

            # res3
            xyz, mask, features = self.layer2(xyz, mask, features)
            end_points['res3_xyz'] = xyz
            end_points['res3_mask'] = mask
            end_points['res3_features'] = features

            # res4
            xyz, mask, features = self.layer3(xyz, mask, features)
            end_points['res4_xyz'] = xyz
            end_points['res4_mask'] = mask
            end_points['res4_features'] = features

            # res5
            xyz, mask, features = self.layer4(xyz, mask, features)
            end_points['res5_xyz'] = xyz
            end_points['res5_mask'] = mask
            end_points['res5_features'] = features

            return end_points
