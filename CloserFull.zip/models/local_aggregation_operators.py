import os
import sys

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(BASE_DIR)
sys.path.append(ROOT_DIR)
sys.path.append(os.path.join(ROOT_DIR, 'ops', 'pt_custom_ops'))

import torch
import torch.nn as nn
import torch.nn.functional as F
from .utlis import create_kernel_points, radius_gaussian, weight_variable
from pt_utils import MaskedQueryAndGroup
from torch_cluster import grid_cluster


class PosPool(nn.Module):
    def __init__(self, in_channels, out_channels, radius, nsample, config):
        """A PosPool operator for local aggregation

        Args:
            in_channels: input channels.
            out_channels: output channels.
            radius: ball query radius
            nsample: neighborhood limit.
            config: config file
        """
        super(PosPool, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.radius = radius
        self.nsample = nsample
        self.position_embedding = config.pospool.position_embedding
        self.reduction = config.pospool.reduction
        self.output_conv = config.pospool.output_conv or (self.in_channels != self.out_channels)

        self.grouper = MaskedQueryAndGroup(radius, nsample, use_xyz=False, ret_grouped_xyz=True, normalize_xyz=True)
        if self.output_conv:
            self.out_conv = nn.Sequential(
                nn.Conv1d(in_channels, out_channels, kernel_size=1, bias=False),
                nn.BatchNorm1d(out_channels, momentum=config.bn_momentum),
                nn.ReLU(inplace=True))
        else:
            self.out_transform = nn.Sequential(
                nn.BatchNorm1d(out_channels, momentum=config.bn_momentum),
                nn.ReLU(inplace=True))

    def forward(self, query_xyz, support_xyz, query_mask, support_mask, support_features):
        """
        Args:
            query_xyz: [B, N1, 3], query points.
            support_xyz: [B, N2, 3], support points.
            query_mask: [B, N1], mask for query points.
            support_mask: [B, N2], mask for support points.
            support_features: [B, C_in, N2], input features of support points.

        Returns:
           output features of query points: [B, C_out, 3]
        """
        B = query_xyz.shape[0]
        C = support_features.shape[1]
        npoint = query_xyz.shape[1]
        neighborhood_features, relative_position, neighborhood_mask = self.grouper(query_xyz, support_xyz, query_mask,
                                                                                   support_mask, support_features)

        if self.position_embedding == 'xyz':
            position_embedding = torch.unsqueeze(relative_position, 1)
            aggregation_features = neighborhood_features.view(B, C // 3, 3, npoint, self.nsample)
            aggregation_features = position_embedding * aggregation_features  # (B, C//3, 3, npoint, nsample)
            aggregation_features = aggregation_features.view(B, C, npoint, self.nsample)  # (B, C, npoint, nsample)
        elif self.position_embedding == 'sin_cos':
            feat_dim = C // 6
            wave_length = 1000
            alpha = 100
            feat_range = torch.arange(feat_dim, dtype=torch.float32).to(query_xyz.device)  # (feat_dim, )
            dim_mat = torch.pow(1.0 * wave_length, (1.0 / feat_dim) * feat_range)  # (feat_dim, )
            position_mat = torch.unsqueeze(alpha * relative_position, -1)  # (B, 3, npoint, nsample, 1)
            div_mat = torch.div(position_mat, dim_mat)  # (B, 3, npoint, nsample, feat_dim)
            sin_mat = torch.sin(div_mat)  # (B, 3, npoint, nsample, feat_dim)
            cos_mat = torch.cos(div_mat)  # (B, 3, npoint, nsample, feat_dim)
            position_embedding = torch.cat([sin_mat, cos_mat], -1)  # (B, 3, npoint, nsample, 2*feat_dim)
            position_embedding = position_embedding.permute(0, 1, 4, 2, 3).contiguous()
            position_embedding = position_embedding.view(B, C, npoint, self.nsample)  # (B, C, npoint, nsample)
            aggregation_features = neighborhood_features * position_embedding  # (B, C, npoint, nsample)
        else:
            raise NotImplementedError(f'Position Embedding {self.position_embedding} not implemented in PosPool')

        if self.reduction == 'max':
            out_features = F.max_pool2d(
                aggregation_features, kernel_size=[1, self.nsample]
            )
            out_features = torch.squeeze(out_features, -1)
        elif self.reduction == 'avg' or self.reduction == 'mean':
            feature_mask = neighborhood_mask + (1 - query_mask[:, :, None])
            feature_mask = feature_mask[:, None, :, :]
            aggregation_features *= feature_mask
            out_features = aggregation_features.sum(-1)
            neighborhood_num = feature_mask.sum(-1)
            out_features /= neighborhood_num
        elif self.reduction == 'sum':
            feature_mask = neighborhood_mask + (1 - query_mask[:, :, None])
            feature_mask = feature_mask[:, None, :, :]
            aggregation_features *= feature_mask
            out_features = aggregation_features.sum(-1)
        else:
            raise NotImplementedError(f'Reduction {self.reduction} not implemented in PosPool ')

        if self.output_conv:
            out_features = self.out_conv(out_features)
        else:
            out_features = self.out_transform(out_features)

        return out_features

class PosPool_LRF(nn.Module):
    def __init__(self, in_channels, out_channels, radius, nsample, config, trans):
        """A PosPool operator for local aggregation

        Args:
            in_channels: input channels.
            out_channels: output channels.
            radius: ball query radius
            nsample: neighborhood limit.
            config: config file
        """
        super(PosPool_LRF, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.radius = radius
        self.nsample = nsample
        self.position_embedding = config.pospool.position_embedding
        self.reduction = config.pospool.reduction
        self.output_conv = config.pospool.output_conv or (self.in_channels != self.out_channels)

        self.grouper = MaskedQueryAndGroup(radius, nsample, use_xyz=False, ret_grouped_xyz=True, normalize_xyz=True)
        if self.output_conv:
            self.out_conv = nn.Sequential(
                nn.Conv1d(in_channels, out_channels, kernel_size=1, bias=False),
                nn.BatchNorm1d(out_channels, momentum=config.bn_momentum),
                nn.ReLU(inplace=True))
        else:
            self.out_transform = nn.Sequential(
                nn.BatchNorm1d(out_channels, momentum=config.bn_momentum),
                nn.ReLU(inplace=True))


        self.voxel=8.0
        self.bottleneck_channel = max(32,in_channels//2)
        self.projectFrom= nn.Sequential(
                                             # nn.Conv2d(out_channels, int(out_channels*0.5), 1),
                                             # nn.BatchNorm2d(int(out_channels*0.5)),
                                             # nn.ReLU(),
                                             nn.Conv2d(int(out_channels), 3, 1),
                                             nn.BatchNorm2d(3),
                                             nn.ReLU())


        self.conv1_forFusion= nn.Sequential(
                                             nn.Conv2d(out_channels, self.bottleneck_channel, 1),
                                             nn.BatchNorm2d(self.bottleneck_channel))

        self.projectBack_forFusion= nn.Sequential(
                                             nn.Conv2d(int(3*self.voxel*self.voxel*self.voxel),  self.bottleneck_channel,1),)
                                             # nn.BatchNorm2d( self.bottleneck_channel))

        self.projectBack= nn.Sequential(
                                             nn.Conv2d(int(3*self.voxel*self.voxel*self.voxel),  out_channels, 1),
                                             nn.BatchNorm2d(out_channels),
                                             nn.ReLU())

        self.Fusion= nn.Sequential(
                                             nn.Conv2d(out_channels, out_channels, 1),
                                             nn.BatchNorm2d(out_channels),
                                             # nn.ReLU(),
                                             # nn.Conv2d(out_channels,out_channels, 1),
                                             # nn.BatchNorm2d(out_channels),
                                             nn.ReLU())

        self.T =trans
        self.siz=torch.Tensor([2.0001/self.voxel,2.0001/self.voxel,2.0001/self.voxel])
        self.star  =torch.Tensor([-1.0,-1.0,-1.0])
        self.end  =torch.Tensor([1.0,1.0,1.0])
        self.tanh = torch.nn.Sequential(nn.Sigmoid())


    def computeSGCDirect(self, pos, BN, M,C,siz,star,end):    ##pos : {B*N*M, C}

            cluster_inds = grid_cluster(pos, siz,start=star,end=end)             ##: {B*N*M}
            cluster_gather = []

            for ii in range(C):
                cluster_gather.append(cluster_inds.unsqueeze(1)*C+ii)

            cluster_inds = torch.cat(cluster_gather,dim=1).view(-1)   ## 100,  32

            final_inds = torch.linspace(0, (BN-1)*int(pow(self.voxel,C))*C, BN).unsqueeze(1).repeat(1, M*C).view(-1).cuda()    ##: {B*N*M*C}
            final_inds += cluster_inds

            reduced_pos = (pos).view(BN*M*C)          #{B*N, M*C}
            reduced_Num = torch.ones(BN*M*C).cuda()

            finResult = torch.zeros(BN,int(pow(self.voxel,C))*C).cuda()             ##    B*N ,voxel^3 ,3
            finResult_Num = torch.zeros(BN,int(pow(self.voxel,C))*C).cuda()   ##    B*N ,voxel^3 ,3
            # reduced_Num = torch.cuda.FloatTensor(BN*M*C).fill_(1.0) #  torch.ones(BN*M*C).cuda()
            #
            # finResult =  torch.cuda.FloatTensor(BN,int(pow(voxel,C))*C).fill_(0.0)   #torch.zeros(BN,int(pow(voxel,C))*C).cuda()             ##    B*N ,voxel^3 ,3
            # finResult_Num = torch.cuda.FloatTensor(BN,int(pow(voxel,C))*C).fill_(0.0) #torch.zeros(BN,int(pow(voxel,C))*C).cuda()   ##    B*N ,voxel^3 ,3


            finResult.put_(final_inds.long(), reduced_pos, accumulate=True)
            finResult_Num.put_(final_inds.long(), reduced_Num, accumulate=True)

            finResult = finResult/(finResult_Num+1.0e-6)

        ###B*N*Featuresize
            return finResult


    def compueSGC(self, grouped_points):   ## input [B,  S, K , D]
         # print("before")
         # print(grouped_points.shape)

         if (torch.isnan(grouped_points.contiguous().view(-1)).sum().item()!=0):
             print("input in compute sgc has nan")
         grouped_points = grouped_points
         B,S,K,D = grouped_points.size()
         groups_mean = grouped_points.mean(2, keepdim=True).repeat(1,1,K, 1)

         diffFeature = grouped_points-groups_mean
         diffFeature = diffFeature.contiguous().view(-1, K, D)  # [B*S, K, D]

         diffFeatureNorm = diffFeature

         # print("diff feature")
         # print(diffFeatureNorm.shape)
         # print('\n')

         learnTrans, weight = self.T(diffFeatureNorm.permute(0,2,1),self.nsample)  ##input B,3,N
         projectedDiffFeature = torch.bmm(learnTrans, diffFeatureNorm.permute(0,2,1)).permute(0,2,1)   ##B,N,3-> B x 3 x N,  -> B,N,3

         # print("before\n")
         # print(projectedDiffFeature.max())
         # print(projectedDiffFeature.min())

         max_length=torch.max(torch.norm(projectedDiffFeature,dim=2,p=2),dim=1)[0]+0.00001
         projectedDiffFeature = projectedDiffFeature/max_length.unsqueeze(-1).unsqueeze(-1)

         B1, M1, C1 = projectedDiffFeature.size()

         siz =self.siz.cuda()
         star =self.star.cuda()
         end =self.end.cuda()

         sgc_feature = self.computeSGCDirect(projectedDiffFeature.contiguous().view(-1,C1),B1,M1, 3, siz, star, end)
         sgc_feature_forCalc = sgc_feature%(1.0/self.voxel)

         sgc_feature = sgc_feature.contiguous().view(B,S,-1)   ### B1, voxel*voxel*voxel

         xx=torch.sum(sgc_feature_forCalc,dim=0)+1.0e-6
         sgc_var = -1.0* xx*torch.log(xx)
         sgc_var =  torch.sum(sgc_var)  #torch.mean(torch.var(sgc_feature_forCalc,dim=-1))
         # torch.clamp(torch.nn.functional.relu(torch.var(projectedDiffFeature,dim=-1)- self.thres),min=0.0,max=1.0)
         return sgc_feature,learnTrans, weight, sgc_var #torch.clamp(torch.nn.functional.relu(torch.var(projectedDiffFeature,dim=-1)- self.thres),min=0.0,max=1.0)

    def aggreateSGC(self, grouped_points):   # [B, D, K, S]
             B,D,K,S = grouped_points.size()

             features = self.projectFrom(grouped_points).permute(0,3,2,1) # [BSKD]
             features, trans, weight, thisVar = self.compueSGC(features)     # [B, S, D']

             features = features.contiguous().view(B*S,-1)
             features = features*weight
             features = features.contiguous().view(B,S,-1).transpose(1, 2).unsqueeze(2)

             return  features, trans, thisVar

    def forward(self, query_xyz, support_xyz, query_mask, support_mask, support_features):
        """
        Args:
            query_xyz: [B, N1, 3], query points.
            support_xyz: [B, N2, 3], support points.
            query_mask: [B, N1], mask for query points.
            support_mask: [B, N2], mask for support points.
            support_features: [B, C_in, N2], input features of support points.

        Returns:
           output features of query points: [B, C_out, 3]
        """
        B = query_xyz.shape[0]
        C = support_features.shape[1]
        npoint = query_xyz.shape[1]
        neighborhood_features, relative_position, neighborhood_mask = self.grouper(query_xyz, support_xyz, query_mask,
                                                                                   support_mask, support_features)

        if self.position_embedding == 'xyz':
            position_embedding = torch.unsqueeze(relative_position, 1)
            aggregation_features = neighborhood_features.view(B, C // 3, 3, npoint, self.nsample)
            aggregation_features = position_embedding * aggregation_features  # (B, C//3, 3, npoint, nsample)
            aggregation_features = aggregation_features.view(B, C, npoint, self.nsample)  # (B, C, npoint, nsample)
        elif self.position_embedding == 'sin_cos':
            feat_dim = C // 6
            wave_length = 1000
            alpha = 100
            feat_range = torch.arange(feat_dim, dtype=torch.float32).to(query_xyz.device)  # (feat_dim, )
            dim_mat = torch.pow(1.0 * wave_length, (1.0 / feat_dim) * feat_range)  # (feat_dim, )
            position_mat = torch.unsqueeze(alpha * relative_position, -1)  # (B, 3, npoint, nsample, 1)
            div_mat = torch.div(position_mat, dim_mat)  # (B, 3, npoint, nsample, feat_dim)
            sin_mat = torch.sin(div_mat)  # (B, 3, npoint, nsample, feat_dim)
            cos_mat = torch.cos(div_mat)  # (B, 3, npoint, nsample, feat_dim)
            position_embedding = torch.cat([sin_mat, cos_mat], -1)  # (B, 3, npoint, nsample, 2*feat_dim)
            position_embedding = position_embedding.permute(0, 1, 4, 2, 3).contiguous()
            position_embedding = position_embedding.view(B, C, npoint, self.nsample)  # (B, C, npoint, nsample)
            aggregation_features = neighborhood_features * position_embedding  # (B, C, npoint, nsample)
        else:
            raise NotImplementedError(f'Position Embedding {self.position_embedding} not implemented in PosPool')



        aggregation_features =aggregation_features.permute(0,1,3,2)

        # (B, D, npoint, nsample)
        sgcFeature, trans, thisVar =  self.aggreateSGC(aggregation_features)  ## [B, D, S]

################ attentive fusion
        B,D,K,S = aggregation_features.size()

        new_points_projected = self.conv1_forFusion((aggregation_features)).permute(0,3,2,1)   ## [B, S, K , D]
        sgc_projected = self.projectBack_forFusion(sgcFeature).permute(0,3,2,1)   ## [B, S, 1 , D]
        weights = torch.bmm(new_points_projected.contiguous().view(B*S,K,-1), sgc_projected.contiguous().view(B*S,1,-1).permute(0,2,1))  ## BSK1
        weights = self.tanh(weights).contiguous().view(B,S,K,1).permute(0,3,2,1).repeat(1,D,1,1)  ## B S K 1   -> B1 K S

        sgc_aggreate_feature = self.projectBack(sgcFeature) ## [B, S, 1 , D]

        aggregation_features = aggregation_features + weights* (sgc_aggreate_feature.repeat(1,1,K,1))
        aggregation_features = self.Fusion(aggregation_features)

        ################
        aggregation_features =aggregation_features.permute(0,1,3,2)


        if self.reduction == 'max':
            out_features = F.max_pool2d(
                aggregation_features, kernel_size=[1, self.nsample]
            )
            out_features = torch.squeeze(out_features, -1)
        elif self.reduction == 'avg' or self.reduction == 'mean':
            feature_mask = neighborhood_mask + (1 - query_mask[:, :, None])
            feature_mask = feature_mask[:, None, :, :]
            aggregation_features *= feature_mask
            out_features = aggregation_features.sum(-1)
            neighborhood_num = feature_mask.sum(-1)
            out_features /= neighborhood_num
        elif self.reduction == 'sum':
            feature_mask = neighborhood_mask + (1 - query_mask[:, :, None])
            feature_mask = feature_mask[:, None, :, :]
            aggregation_features *= feature_mask
            out_features = aggregation_features.sum(-1)
        else:
            raise NotImplementedError(f'Reduction {self.reduction} not implemented in PosPool ')

        if self.output_conv:
            out_features = self.out_conv(out_features)
        else:
            out_features = self.out_transform(out_features)

        return out_features, trans, thisVar


class AdaptiveWeight(nn.Module):
    def __init__(self, in_channels, out_channels, radius, nsample, config):
        """A AdaptiveWeight operator for local aggregation

        Args:
            in_channels: input channels.
            out_channels: output channels.
            radius: ball query radius
            nsample: neighborhood limit.
            config: config file
        """
        super(AdaptiveWeight, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.nsample = nsample
        self.weight_type = config.adaptive_weight.weight_type
        self.weight_to_channels = {'dp': 3,
                                   'df': in_channels,
                                   'fj': in_channels,
                                   'dp_df': 3 + in_channels,
                                   'dp_fj': 3 + in_channels,
                                   'fi_df': 2 * in_channels,
                                   'dp_fi_df': 3 + 2 * in_channels,
                                   'rscnn': 10}
        self.weight_input_channels = self.weight_to_channels[self.weight_type]
        self.num_mlps = config.adaptive_weight.num_mlps
        self.shared_channels = config.adaptive_weight.shared_channels
        self.weight_softmax = config.adaptive_weight.weight_softmax
        self.reduction = config.adaptive_weight.reduction
        self.output_conv = config.adaptive_weight.output_conv or (self.in_channels != self.out_channels)

        self.grouper = MaskedQueryAndGroup(radius, nsample, use_xyz=False, ret_grouped_xyz=True, normalize_xyz=True)

        self.mlps = nn.Sequential()
        self.mlps.add_module('conv0',
                             nn.Conv2d(self.weight_input_channels,
                                       self.in_channels // self.shared_channels,
                                       kernel_size=1))
        for i in range(self.num_mlps - 1):
            self.mlps.add_module(f'relu{i}', nn.ReLU(inplace=True))
            self.mlps.add_module(f'conv{i + 1}',
                                 nn.Conv2d(self.in_channels // self.shared_channels,
                                           self.in_channels // self.shared_channels,
                                           kernel_size=1))

        if self.output_conv:
            self.out_conv = nn.Sequential(
                nn.Conv1d(in_channels, out_channels, kernel_size=1, bias=False),
                nn.BatchNorm1d(out_channels, momentum=config.bn_momentum),
                nn.ReLU(inplace=True))
        else:
            self.out_transform = nn.Sequential(
                nn.BatchNorm1d(out_channels, momentum=config.bn_momentum),
                nn.ReLU(inplace=True))

    def forward(self, query_xyz, support_xyz, query_mask, support_mask, support_features):
        """
        Args:
            query_xyz: [B, N1, 3], query points.
            support_xyz: [B, N2, 3], support points.
            query_mask: [B, N1], mask for query points.
            support_mask: [B, N2], mask for support points.
            support_features: [B, C_in, N2], input features of support points.

        Returns:
           output features of query points: [B, C_out, 3]
        """
        B = query_xyz.shape[0]
        C = support_features.shape[1]
        npoint = query_xyz.shape[1]
        neighborhood_features, relative_position, neighborhood_mask = self.grouper(query_xyz, support_xyz, query_mask,
                                                                                   support_mask, support_features)

        if self.weight_type == 'dp':
            conv_weight = self.mlps(relative_position)  # (B, C//S, npoint, nsample)
            conv_weight = torch.unsqueeze(conv_weight, 2)  # (B, C//S, 1, npoint, nsample)
        else:
            raise NotImplementedError(f'Weight Type {self.weight_type} not implemented in AdaptiveWeight')

        aggregation_features = neighborhood_features.view(B, C // self.shared_channels, self.shared_channels,
                                                          npoint, self.nsample)
        aggregation_features = aggregation_features * conv_weight
        aggregation_features = aggregation_features.view(B, C, npoint, self.nsample)

        if self.reduction == 'max':
            out_features = F.max_pool2d(
                aggregation_features, kernel_size=[1, self.nsample]
            )
            out_features = torch.squeeze(out_features, -1)
        elif self.reduction == 'avg' or self.reduction == 'mean':
            feature_mask = neighborhood_mask + (1 - query_mask[:, :, None])
            feature_mask = feature_mask[:, None, :, :]
            aggregation_features *= feature_mask
            out_features = aggregation_features.sum(-1)
            neighborhood_num = feature_mask.sum(-1)
            out_features /= neighborhood_num
        elif self.reduction == 'sum':
            feature_mask = neighborhood_mask + (1 - query_mask[:, :, None])
            feature_mask = feature_mask[:, None, :, :]
            aggregation_features *= feature_mask
            out_features = aggregation_features.sum(-1)
        else:
            raise NotImplementedError(f'Reduction {self.reduction} not implemented in PosPool ')

        if self.output_conv:
            out_features = self.out_conv(out_features)
        else:
            out_features = self.out_transform(out_features)

        return out_features

class AdaptiveWeight_LRF(nn.Module):
    def __init__(self, in_channels, out_channels, radius, nsample, config, trans):
        """A AdaptiveWeight operator for local aggregation

        Args:
            in_channels: input channels.
            out_channels: output channels.
            radius: ball query radius
            nsample: neighborhood limit.
            config: config file
        """
        super(AdaptiveWeight_LRF, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.nsample = nsample
        self.weight_type = config.adaptive_weight.weight_type
        self.weight_to_channels = {'dp': 3,
                                   'df': in_channels,
                                   'fj': in_channels,
                                   'dp_df': 3 + in_channels,
                                   'dp_fj': 3 + in_channels,
                                   'fi_df': 2 * in_channels,
                                   'dp_fi_df': 3 + 2 * in_channels,
                                   'rscnn': 10}
        self.weight_input_channels = self.weight_to_channels[self.weight_type]
        self.num_mlps = config.adaptive_weight.num_mlps
        self.shared_channels = config.adaptive_weight.shared_channels
        self.weight_softmax = config.adaptive_weight.weight_softmax
        self.reduction = config.adaptive_weight.reduction
        self.output_conv = config.adaptive_weight.output_conv or (self.in_channels != self.out_channels)

        self.grouper = MaskedQueryAndGroup(radius, nsample, use_xyz=False, ret_grouped_xyz=True, normalize_xyz=True)

        self.mlps = nn.Sequential()
        self.mlps.add_module('conv0',
                             nn.Conv2d(self.weight_input_channels,
                                       self.in_channels // self.shared_channels,
                                       kernel_size=1))
        for i in range(self.num_mlps - 1):
            self.mlps.add_module(f'relu{i}', nn.ReLU(inplace=True))
            self.mlps.add_module(f'conv{i + 1}',
                                 nn.Conv2d(self.in_channels // self.shared_channels,
                                           self.in_channels // self.shared_channels,
                                           kernel_size=1))

        if self.output_conv:
            self.out_conv = nn.Sequential(
                nn.Conv1d(in_channels, out_channels, kernel_size=1, bias=False),
                nn.BatchNorm1d(out_channels, momentum=config.bn_momentum),
                nn.ReLU(inplace=True))
        else:
            self.out_transform = nn.Sequential(
                nn.BatchNorm1d(out_channels, momentum=config.bn_momentum),
                nn.ReLU(inplace=True))

        self.voxel=8.0
        self.bottleneck_channel = max(32,in_channels//2)
        self.projectFrom= nn.Sequential(
                                             # nn.Conv2d(out_channels, int(out_channels*0.5), 1),
                                             # nn.BatchNorm2d(int(out_channels*0.5)),
                                             # nn.ReLU(),
                                             nn.Conv2d(int(out_channels), 3, 1),
                                             nn.BatchNorm2d(3),
                                             nn.ReLU())


        self.conv1_forFusion= nn.Sequential(
                                             nn.Conv2d(out_channels, self.bottleneck_channel, 1),
                                             nn.BatchNorm2d(self.bottleneck_channel))

        self.projectBack_forFusion= nn.Sequential(
                                             nn.Conv2d(int(3*self.voxel*self.voxel*self.voxel),  self.bottleneck_channel,1),)
                                             # nn.BatchNorm2d( self.bottleneck_channel))

        self.projectBack= nn.Sequential(
                                             nn.Conv2d(int(3*self.voxel*self.voxel*self.voxel),  out_channels, 1),
                                             nn.BatchNorm2d(out_channels),
                                             nn.ReLU())

        self.Fusion= nn.Sequential(
                                             nn.Conv2d(out_channels, out_channels, 1),
                                             nn.BatchNorm2d(out_channels),
                                             # nn.ReLU(),
                                             # nn.Conv2d(out_channels,out_channels, 1),
                                             # nn.BatchNorm2d(out_channels),
                                             nn.ReLU())

        self.T =trans
        self.siz=torch.Tensor([2.0001/self.voxel,2.0001/self.voxel,2.0001/self.voxel])
        self.star  =torch.Tensor([-1.0,-1.0,-1.0])
        self.end  =torch.Tensor([1.0,1.0,1.0])
        self.tanh = torch.nn.Sequential(nn.Sigmoid())

    def computeSGCDirect(self, pos, BN, M,C,siz,star,end):    ##pos : {B*N*M, C}

            cluster_inds = grid_cluster(pos, siz,start=star,end=end)             ##: {B*N*M}
            cluster_gather = []

            for ii in range(C):
                cluster_gather.append(cluster_inds.unsqueeze(1)*C+ii)

            cluster_inds = torch.cat(cluster_gather,dim=1).view(-1)   ## 100,  32

            final_inds = torch.linspace(0, (BN-1)*int(pow(self.voxel,C))*C, BN).unsqueeze(1).repeat(1, M*C).view(-1).cuda()    ##: {B*N*M*C}
            final_inds += cluster_inds

            reduced_pos = (pos).view(BN*M*C)          #{B*N, M*C}
            reduced_Num = torch.ones(BN*M*C).cuda()

            finResult = torch.zeros(BN,int(pow(self.voxel,C))*C).cuda()             ##    B*N ,voxel^3 ,3
            finResult_Num = torch.zeros(BN,int(pow(self.voxel,C))*C).cuda()   ##    B*N ,voxel^3 ,3
            # reduced_Num = torch.cuda.FloatTensor(BN*M*C).fill_(1.0) #  torch.ones(BN*M*C).cuda()
            #
            # finResult =  torch.cuda.FloatTensor(BN,int(pow(voxel,C))*C).fill_(0.0)   #torch.zeros(BN,int(pow(voxel,C))*C).cuda()             ##    B*N ,voxel^3 ,3
            # finResult_Num = torch.cuda.FloatTensor(BN,int(pow(voxel,C))*C).fill_(0.0) #torch.zeros(BN,int(pow(voxel,C))*C).cuda()   ##    B*N ,voxel^3 ,3


            finResult.put_(final_inds.long(), reduced_pos, accumulate=True)
            finResult_Num.put_(final_inds.long(), reduced_Num, accumulate=True)

            finResult = finResult/(finResult_Num+1.0e-6)

        ###B*N*Featuresize
            return finResult

    def compueSGC(self, grouped_points):   ## input [B,  S, K , D]
         # print("before")
         # print(grouped_points.shape)

         if (torch.isnan(grouped_points.contiguous().view(-1)).sum().item()!=0):
             print("input in compute sgc has nan")
         grouped_points = grouped_points
         B,S,K,D = grouped_points.size()
         groups_mean = grouped_points.mean(2, keepdim=True).repeat(1,1,K, 1)

         diffFeature = grouped_points-groups_mean
         diffFeature = diffFeature.contiguous().view(-1, K, D)  # [B*S, K, D]

         diffFeatureNorm = diffFeature

         # print("diff feature")
         # print(diffFeatureNorm.shape)
         # print('\n')

         learnTrans, weight = self.T(diffFeatureNorm.permute(0,2,1),self.nsample)  ##input B,3,N
         projectedDiffFeature = torch.bmm(learnTrans, diffFeatureNorm.permute(0,2,1)).permute(0,2,1)   ##B,N,3-> B x 3 x N,  -> B,N,3

         # print("before\n")
         # print(projectedDiffFeature.max())
         # print(projectedDiffFeature.min())

         max_length=torch.max(torch.norm(projectedDiffFeature,dim=2,p=2),dim=1)[0]+0.00001
         projectedDiffFeature = projectedDiffFeature/max_length.unsqueeze(-1).unsqueeze(-1)

         B1, M1, C1 = projectedDiffFeature.size()

         siz =self.siz.cuda()
         star =self.star.cuda()
         end =self.end.cuda()

         sgc_feature = self.computeSGCDirect(projectedDiffFeature.contiguous().view(-1,C1),B1,M1, 3, siz, star, end)
         sgc_feature_forCalc = sgc_feature%(1.0/self.voxel)

         sgc_feature = sgc_feature.contiguous().view(B,S,-1)   ### B1, voxel*voxel*voxel

         xx=torch.sum(sgc_feature_forCalc,dim=0)+1.0e-6
         sgc_var = -1.0* xx*torch.log(xx)
         sgc_var =  torch.sum(sgc_var)  #torch.mean(torch.var(sgc_feature_forCalc,dim=-1))
         # torch.clamp(torch.nn.functional.relu(torch.var(projectedDiffFeature,dim=-1)- self.thres),min=0.0,max=1.0)
         return sgc_feature,learnTrans, weight, sgc_var #torch.clamp(torch.nn.functional.relu(torch.var(projectedDiffFeature,dim=-1)- self.thres),min=0.0,max=1.0)

    def aggreateSGC(self, grouped_points):   # [B, D, K, S]
             B,D,K,S = grouped_points.size()

             features = self.projectFrom(grouped_points).permute(0,3,2,1) # [BSKD]
             features, trans, weight, thisVar = self.compueSGC(features)     # [B, S, D']

             features = features.contiguous().view(B*S,-1)
             features = features*weight
             features = features.contiguous().view(B,S,-1).transpose(1, 2).unsqueeze(2)

             return  features, trans, thisVar


    def forward(self, query_xyz, support_xyz, query_mask, support_mask, support_features):
        """
        Args:
            query_xyz: [B, N1, 3], query points.
            support_xyz: [B, N2, 3], support points.
            query_mask: [B, N1], mask for query points.
            support_mask: [B, N2], mask for support points.
            support_features: [B, C_in, N2], input features of support points.

        Returns:
           output features of query points: [B, C_out, 3]
        """
        B = query_xyz.shape[0]
        C = support_features.shape[1]
        npoint = query_xyz.shape[1]
        neighborhood_features, relative_position, neighborhood_mask = self.grouper(query_xyz, support_xyz, query_mask,
                                                                                   support_mask, support_features)

        if self.weight_type == 'dp':
            conv_weight = self.mlps(relative_position)  # (B, C//S, npoint, nsample)
            conv_weight = torch.unsqueeze(conv_weight, 2)  # (B, C//S, 1, npoint, nsample)
        else:
            raise NotImplementedError(f'Weight Type {self.weight_type} not implemented in AdaptiveWeight')

        aggregation_features = neighborhood_features.view(B, C // self.shared_channels, self.shared_channels,
                                                          npoint, self.nsample)
        aggregation_features = aggregation_features * conv_weight
        aggregation_features = aggregation_features.view(B, C, npoint, self.nsample)

#################################
        aggregation_features =aggregation_features.permute(0,1,3,2)

        # (B, D, npoint, nsample)
        sgcFeature, trans, thisVar =  self.aggreateSGC(aggregation_features)  ## [B, D, S]

################ attentive fusion
        B,D,K,S = aggregation_features.size()

        new_points_projected = self.conv1_forFusion((aggregation_features)).permute(0,3,2,1)   ## [B, S, K , D]
        sgc_projected = self.projectBack_forFusion(sgcFeature).permute(0,3,2,1)   ## [B, S, 1 , D]
        weights = torch.bmm(new_points_projected.contiguous().view(B*S,K,-1), sgc_projected.contiguous().view(B*S,1,-1).permute(0,2,1))  ## BSK1
        weights = self.tanh(weights).contiguous().view(B,S,K,1).permute(0,3,2,1).repeat(1,D,1,1)  ## B S K 1   -> B1 K S

        sgc_aggreate_feature = self.projectBack(sgcFeature) ## [B, S, 1 , D]

        aggregation_features = aggregation_features + weights* (sgc_aggreate_feature.repeat(1,1,K,1))
        aggregation_features = self.Fusion(aggregation_features)

        ################
        aggregation_features =aggregation_features.permute(0,1,3,2)
#########


        if self.reduction == 'max':
            out_features = F.max_pool2d(
                aggregation_features, kernel_size=[1, self.nsample]
            )
            out_features = torch.squeeze(out_features, -1)
        elif self.reduction == 'avg' or self.reduction == 'mean':
            feature_mask = neighborhood_mask + (1 - query_mask[:, :, None])
            feature_mask = feature_mask[:, None, :, :]
            aggregation_features *= feature_mask
            out_features = aggregation_features.sum(-1)
            neighborhood_num = feature_mask.sum(-1)
            out_features /= neighborhood_num
        elif self.reduction == 'sum':
            feature_mask = neighborhood_mask + (1 - query_mask[:, :, None])
            feature_mask = feature_mask[:, None, :, :]
            aggregation_features *= feature_mask
            out_features = aggregation_features.sum(-1)
        else:
            raise NotImplementedError(f'Reduction {self.reduction} not implemented in PosPool ')

        if self.output_conv:
            out_features = self.out_conv(out_features)
        else:
            out_features = self.out_transform(out_features)

        return out_features, trans, thisVar

class PointWiseMLP(nn.Module):
    def __init__(self, in_channels, out_channels, radius, nsample, config):
        """A PointWiseMLP operator for local aggregation

        Args:
            in_channels: input channels.
            out_channels: output channels.
            radius: ball query radius
            nsample: neighborhood limit.
            config: config file
        """
        super(PointWiseMLP, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.nsample = nsample
        self.feature_type = config.pointwisemlp.feature_type
        self.feature_input_channels = {'dp_fj': 3 + in_channels,
                                       'fi_df': 2 * in_channels,
                                       'dp_fi_df': 3 + 2 * in_channels}
        self.feature_input_channels = self.feature_input_channels[self.feature_type]
        self.num_mlps = config.pointwisemlp.num_mlps
        self.reduction = config.pointwisemlp.reduction

        self.grouper = MaskedQueryAndGroup(radius, nsample, use_xyz=False, ret_grouped_xyz=True, normalize_xyz=True)

        self.mlps = nn.Sequential()
        if self.num_mlps == 1:
            self.mlps.add_module('conv0', nn.Sequential(
                nn.Conv2d(self.feature_input_channels, self.out_channels, kernel_size=1, bias=False),
                nn.BatchNorm2d(self.out_channels, momentum=config.bn_momentum),
                nn.ReLU(inplace=True)))
        else:
            mfdim = max(self.in_channels // 2, 9)
            self.mlps.add_module('conv0', nn.Sequential(
                nn.Conv2d(self.feature_input_channels, mfdim, kernel_size=1, bias=False),
                nn.BatchNorm2d(mfdim, momentum=config.bn_momentum),
                nn.ReLU(inplace=True)))
            for i in range(self.num_mlps - 2):
                self.mlps.add_module(f'conv{i + 1}', nn.Sequential(
                    nn.Conv2d(mfdim, mfdim, kernel_size=1, bias=False),
                    nn.BatchNorm2d(mfdim, momentum=config.bn_momentum),
                    nn.ReLU(inplace=True)))
            self.mlps.add_module(f'conv{self.num_mlps - 1}', nn.Sequential(
                nn.Conv2d(mfdim, self.out_channels, kernel_size=1, bias=False),
                nn.BatchNorm2d(self.out_channels, momentum=config.bn_momentum),
                nn.ReLU(inplace=True)))

    def forward(self, query_xyz, support_xyz, query_mask, support_mask, support_features):
        """
        Args:
            query_xyz: [B, N1, 3], query points.
            support_xyz: [B, N2, 3], support points.
            query_mask: [B, N1], mask for query points.
            support_mask: [B, N2], mask for support points.
            support_features: [B, C_in, N2], input features of support points.

        Returns:
           output features of query points: [B, C_out, 3]
        """
        neighborhood_features, relative_position, neighborhood_mask = self.grouper(query_xyz, support_xyz, query_mask,
                                                                                   support_mask, support_features)
        if self.feature_type == 'dp_fi_df':
            # B C N M
            center_features = torch.unsqueeze(neighborhood_features[..., 0], -1).repeat([1, 1, 1, self.nsample])
            relative_features = neighborhood_features - center_features
            local_input_features = torch.cat([relative_position, center_features, relative_features], 1)
            aggregation_features = self.mlps(local_input_features)
        else:
            raise NotImplementedError(f'Feature Type {self.feature_type} not implemented in PointWiseMLP')

        if self.reduction == 'max':
            out_features = F.max_pool2d(
                aggregation_features, kernel_size=[1, self.nsample]
            )
            out_features = torch.squeeze(out_features, -1)
        elif self.reduction == 'avg' or self.reduction == 'mean':
            feature_mask = neighborhood_mask + (1 - query_mask[:, :, None])
            feature_mask = feature_mask[:, None, :, :]
            aggregation_features *= feature_mask
            out_features = aggregation_features.sum(-1)
            neighborhood_num = feature_mask.sum(-1)
            out_features /= neighborhood_num
        elif self.reduction == 'sum':
            feature_mask = neighborhood_mask + (1 - query_mask[:, :, None])
            feature_mask = feature_mask[:, None, :, :]
            aggregation_features *= feature_mask
            out_features = aggregation_features.sum(-1)
        else:
            raise NotImplementedError(f'Reduction {self.reduction} not implemented in PointWiseMLP')
        return out_features


class PointWiseMLP_WithLRF(nn.Module):
    def __init__(self, in_channels, out_channels, radius, nsample, config, trans):
        """A PointWiseMLP operator for local aggregation

        Args:
            in_channels: input channels.
            out_channels: output channels.
            radius: ball query radius
            nsample: neighborhood limit.
            config: config file
        """
        super(PointWiseMLP_WithLRF, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.nsample = nsample
        self.feature_type = config.pointwisemlp.feature_type
        self.feature_input_channels = {'dp_fj': 3 + in_channels,
                                       'fi_df': 2 * in_channels,
                                       'dp_fi_df': 3 + 2 * in_channels}
        self.feature_input_channels = self.feature_input_channels[self.feature_type]
        self.num_mlps = config.pointwisemlp.num_mlps
        self.reduction = config.pointwisemlp.reduction

        self.grouper = MaskedQueryAndGroup(radius, nsample, use_xyz=False, ret_grouped_xyz=True, normalize_xyz=True)


        self.mlps = nn.Sequential()
        if self.num_mlps == 1:
            self.mlps.add_module('conv0', nn.Sequential(
                nn.Conv2d(self.feature_input_channels, self.out_channels, kernel_size=1, bias=False),
                nn.BatchNorm2d(self.out_channels, momentum=config.bn_momentum),
                nn.ReLU(inplace=True)))
        else:
            mfdim = max(self.in_channels // 2, 9)
            self.mlps.add_module('conv0', nn.Sequential(
                nn.Conv2d(self.feature_input_channels, mfdim, kernel_size=1, bias=False),
                nn.BatchNorm2d(mfdim, momentum=config.bn_momentum),
                nn.ReLU(inplace=True)))
            for i in range(self.num_mlps - 2):
                self.mlps.add_module(f'conv{i + 1}', nn.Sequential(
                    nn.Conv2d(mfdim, mfdim, kernel_size=1, bias=False),
                    nn.BatchNorm2d(mfdim, momentum=config.bn_momentum),
                    nn.ReLU(inplace=True)))
            self.mlps.add_module(f'conv{self.num_mlps - 1}', nn.Sequential(
                nn.Conv2d(mfdim, self.out_channels, kernel_size=1, bias=False),
                nn.BatchNorm2d(self.out_channels, momentum=config.bn_momentum),
                nn.ReLU(inplace=True)))

        self.voxel=8.0
        self.bottleneck_channel = max(32,in_channels//2)
        self.projectFrom= nn.Sequential(
                                             # nn.Conv2d(out_channels, int(out_channels*0.5), 1),
                                             # nn.BatchNorm2d(int(out_channels*0.5)),
                                             # nn.ReLU(),
                                             nn.Conv2d(int(out_channels), 3, 1),
                                             nn.BatchNorm2d(3),
                                             nn.ReLU())

        self.conv1_forFusion= nn.Sequential(
                                             nn.Conv2d(out_channels, self.bottleneck_channel, 1),
                                             nn.BatchNorm2d(self.bottleneck_channel))

        self.projectBack_forFusion= nn.Sequential(
                                             nn.Conv2d(int(3*self.voxel*self.voxel*self.voxel),  self.bottleneck_channel,1),)
                                             # nn.BatchNorm2d( self.bottleneck_channel))

        self.projectBack= nn.Sequential(
                                             nn.Conv2d(int(3*self.voxel*self.voxel*self.voxel),  out_channels, 1),
                                             nn.BatchNorm2d(out_channels),
                                             nn.ReLU())

        self.Fusion= nn.Sequential(
                                             # nn.Conv2d(out_channels, out_channels, 1),
                                             # nn.BatchNorm2d(out_channels),
                                             # nn.ReLU(),
                                             nn.Conv2d(out_channels,out_channels, 1),
                                             nn.BatchNorm2d(out_channels),
                                             nn.ReLU())

        self.T =trans
        self.siz=torch.Tensor([2.0001/self.voxel,2.0001/self.voxel,2.0001/self.voxel])
        self.star  =torch.Tensor([-1.0,-1.0,-1.0])
        self.end  =torch.Tensor([1.0,1.0,1.0])
        self.tanh = torch.nn.Sequential(nn.Sigmoid())


    def computeSGCDirect(self, pos, BN, M,C,siz,star,end):    ##pos : {B*N*M, C}

            cluster_inds = grid_cluster(pos, siz,start=star,end=end)             ##: {B*N*M}
            cluster_gather = []

            for ii in range(C):
                cluster_gather.append(cluster_inds.unsqueeze(1)*C+ii)

            cluster_inds = torch.cat(cluster_gather,dim=1).view(-1)   ## 100,  32

            final_inds = torch.linspace(0, (BN-1)*int(pow(self.voxel,C))*C, BN).unsqueeze(1).repeat(1, M*C).view(-1).cuda()    ##: {B*N*M*C}
            final_inds += cluster_inds

            reduced_pos = (pos).view(BN*M*C)          #{B*N, M*C}
            reduced_Num = torch.ones(BN*M*C).cuda()

            finResult = torch.zeros(BN,int(pow(self.voxel,C))*C).cuda()             ##    B*N ,voxel^3 ,3
            finResult_Num = torch.zeros(BN,int(pow(self.voxel,C))*C).cuda()   ##    B*N ,voxel^3 ,3
            # reduced_Num = torch.cuda.FloatTensor(BN*M*C).fill_(1.0) #  torch.ones(BN*M*C).cuda()
            #
            # finResult =  torch.cuda.FloatTensor(BN,int(pow(voxel,C))*C).fill_(0.0)   #torch.zeros(BN,int(pow(voxel,C))*C).cuda()             ##    B*N ,voxel^3 ,3
            # finResult_Num = torch.cuda.FloatTensor(BN,int(pow(voxel,C))*C).fill_(0.0) #torch.zeros(BN,int(pow(voxel,C))*C).cuda()   ##    B*N ,voxel^3 ,3


            finResult.put_(final_inds.long(), reduced_pos, accumulate=True)
            finResult_Num.put_(final_inds.long(), reduced_Num, accumulate=True)

            finResult = finResult/(finResult_Num+1.0e-6)

        ###B*N*Featuresize
            return finResult

    def compueSGC(self, grouped_points):   ## input [B,  S, K , D]
         # print("before")
         # print(grouped_points.shape)

         if (torch.isnan(grouped_points.contiguous().view(-1)).sum().item()!=0):
             print("input in compute sgc has nan")
         grouped_points = grouped_points
         B,S,K,D = grouped_points.size()
         groups_mean = grouped_points.mean(2, keepdim=True).repeat(1,1,K, 1)

         diffFeature = grouped_points-groups_mean
         diffFeature = diffFeature.contiguous().view(-1, K, D)  # [B*S, K, D]

         diffFeatureNorm = diffFeature

         # print("diff feature")
         # print(diffFeatureNorm.shape)
         # print('\n')

         learnTrans, weight = self.T(diffFeatureNorm.permute(0,2,1),self.nsample)  ##input B,3,N
         projectedDiffFeature = torch.bmm(learnTrans, diffFeatureNorm.permute(0,2,1)).permute(0,2,1)   ##B,N,3-> B x 3 x N,  -> B,N,3

         max_length=torch.max(torch.norm(projectedDiffFeature,dim=2,p=2),dim=1)[0]+0.00001
         projectedDiffFeature = projectedDiffFeature/max_length.unsqueeze(-1).unsqueeze(-1)

         B1, M1, C1 = projectedDiffFeature.size()

         siz =self.siz.cuda()
         star =self.star.cuda()
         end =self.end.cuda()

         sgc_feature = self.computeSGCDirect(projectedDiffFeature.contiguous().view(-1,C1),B1,M1, 3, siz, star, end)
         sgc_feature_forCalc = sgc_feature%(1.0/self.voxel)

         sgc_feature = sgc_feature.contiguous().view(B,S,-1)   ### B1, voxel*voxel*voxel

         xx=torch.sum(sgc_feature_forCalc,dim=0)+1.0e-6
         sgc_var = -1.0* xx*torch.log(xx)
         sgc_var =  torch.sum(sgc_var)  #torch.mean(torch.var(sgc_feature_forCalc,dim=-1))
         # torch.clamp(torch.nn.functional.relu(torch.var(projectedDiffFeature,dim=-1)- self.thres),min=0.0,max=1.0)
         return sgc_feature,learnTrans, weight, sgc_var #torch.clamp(torch.nn.functional.relu(torch.var(projectedDiffFeature,dim=-1)- self.thres),min=0.0,max=1.0)

    def compueSGC_firstpass(self, grouped_points):   ## input [B,  S, K , D]
         # print("before")
         # print(grouped_points.shape)

         if (torch.isnan(grouped_points.contiguous().view(-1)).sum().item()!=0):
             print("input in compute sgc has nan")
         grouped_points = grouped_points
         B,S,K,D = grouped_points.size()
         # print("BSKD")
         # print(grouped_points.size())
         groups_mean = grouped_points.mean(2, keepdim=True).repeat(1,1,K, 1)

         diffFeature = grouped_points-groups_mean
         diffFeature = diffFeature.contiguous().view(-1, K, D)  # [B*S, K, D]

         diffFeatureNorm = diffFeature

         return diffFeatureNorm, self.nsample

    def compueSGC_secondpass(self, grouped_points, learnTrans, diffFeatureNorm):   ## input [B,  S, K , D]
         projectedDiffFeature = torch.bmm(learnTrans, diffFeatureNorm.permute(0,2,1)).permute(0,2,1)   ##B,N,3-> B x 3 x N,  -> B,N,3

         max_length=torch.max(torch.norm(projectedDiffFeature,dim=2,p=2),dim=1)[0]+0.00001
         projectedDiffFeature = projectedDiffFeature/max_length.unsqueeze(-1).unsqueeze(-1)

         B1, M1, C1 = projectedDiffFeature.size()
         B,_,_,S = grouped_points.size()


         siz =self.siz.cuda()
         star =self.star.cuda()
         end =self.end.cuda()

         sgc_feature = self.computeSGCDirect(projectedDiffFeature.contiguous().view(-1,C1),B1,M1, 3, siz, star, end)
         sgc_feature_forCalc = sgc_feature%(1.0/self.voxel)

         sgc_feature = sgc_feature.contiguous().view(B,S,-1)   ### B1, voxel*voxel*voxel

         xx=torch.sum(sgc_feature_forCalc,dim=0)+1.0e-6
         sgc_var = -1.0* xx*torch.log(xx)
         sgc_var =  torch.sum(sgc_var)  #torch.mean(torch.var(sgc_feature_forCalc,dim=-1))
         # torch.clamp(torch.nn.functional.relu(torch.var(projectedDiffFeature,dim=-1)- self.thres),min=0.0,max=1.0)
         return sgc_feature, sgc_var #torch.clamp(torch.nn.functional.relu(torch.var(projectedDiffFeature,dim=-1)- self.thres),min=0.0,max=1.0)


    def aggreateSGC(self, grouped_points):   # [B, D, K, S]
             B,D,K,S = grouped_points.size()

             features = self.projectFrom(grouped_points).permute(0,3,2,1) # [BSKD]
             features, trans, weight, thisVar = self.compueSGC(features)     # [B, S, D']

             features = features.contiguous().view(B*S,-1)
             features = features*weight
             features = features.contiguous().view(B,S,-1).transpose(1, 2).unsqueeze(2)

             return  features, trans, thisVar

    def aggreateSGC_firstpass(self, grouped_points):   # [B, D, K, S]
             B,D,K,S = grouped_points.size()

             features = self.projectFrom(grouped_points).permute(0,3,2,1) # [BSKD]
             diffFeatureNorm, nsample = self.compueSGC_firstpass(features)     # [B, S, D']


             return diffFeatureNorm, nsample


    def aggreateSGC_second_pass(self, grouped_points, learnTrans, diffFeatureNorm, weight):   # [B, D, K, S]
             B,D,K,S = grouped_points.size()
             # print("BDKS--")
             # print(grouped_points.size())
             features, thisVar = self.compueSGC_secondpass(grouped_points, learnTrans, diffFeatureNorm)     # [B, S, D']
             features = features.contiguous().view(B*S,-1)
             features = features*weight
             features = features.contiguous().view(B,S,-1).transpose(1, 2).unsqueeze(2)
             return  features, thisVar

    def forward(self, query_xyz, support_xyz, query_mask, support_mask, support_features):
        """
        Args:
            query_xyz: [B, N1, 3], query points.
            support_xyz: [B, N2, 3], support points.
            query_mask: [B, N1], mask for query points.
            support_mask: [B, N2], mask for support points.
            support_features: [B, C_in, N2], input features of support points.

        Returns:
           output features of query points: [B, C_out, 3]
        """
        neighborhood_features, relative_position, neighborhood_mask = self.grouper(query_xyz, support_xyz, query_mask,
                                                                                   support_mask, support_features)
        if self.feature_type == 'dp_fi_df':
            # B C N M
            center_features = torch.unsqueeze(neighborhood_features[..., 0], -1).repeat([1, 1, 1, self.nsample])
            relative_features = neighborhood_features - center_features

            local_input_features = torch.cat([relative_position, center_features, relative_features], 1)
            aggregation_features = self.mlps(local_input_features)
        else:
            raise NotImplementedError(f'Feature Type {self.feature_type} not implemented in PointWiseMLP')


            ###############
        # print("aggregation_features")
        # print(aggregation_features.shape)

        aggregation_features =aggregation_features.permute(0,1,3,2)

        # (B, D, npoint, nsample)
        sgcFeature, trans, thisVar =  self.aggreateSGC(aggregation_features)  ## [B, D, S]

################ attentive fusion
        B,D,K,S = aggregation_features.size()

        new_points_projected = self.conv1_forFusion((aggregation_features)).permute(0,3,2,1)   ## [B, S, K , D]
        sgc_projected = self.projectBack_forFusion(sgcFeature).permute(0,3,2,1)   ## [B, S, 1 , D]
        weights = torch.bmm(new_points_projected.contiguous().view(B*S,K,-1), sgc_projected.contiguous().view(B*S,1,-1).permute(0,2,1))  ## BSK1
        weights = self.tanh(weights).contiguous().view(B,S,K,1).permute(0,3,2,1).repeat(1,D,1,1)  ## B S K 1   -> B1 K S

        sgc_aggreate_feature = self.projectBack(sgcFeature) ## [B, S, 1 , D]

        aggregation_features = aggregation_features + weights* (sgc_aggreate_feature.repeat(1,1,K,1))
        aggregation_features = self.Fusion(aggregation_features)

        ################
        aggregation_features =aggregation_features.permute(0,1,3,2)


        if self.reduction == 'max':
            out_features = F.max_pool2d(
                aggregation_features, kernel_size=[1, self.nsample]
            )
            out_features = torch.squeeze(out_features, -1)
        elif self.reduction == 'avg' or self.reduction == 'mean':
            feature_mask = neighborhood_mask + (1 - query_mask[:, :, None])
            feature_mask = feature_mask[:, None, :, :]
            aggregation_features *= feature_mask
            out_features = aggregation_features.sum(-1)
            neighborhood_num = feature_mask.sum(-1)
            out_features /= neighborhood_num
        elif self.reduction == 'sum':
            feature_mask = neighborhood_mask + (1 - query_mask[:, :, None])
            feature_mask = feature_mask[:, None, :, :]
            aggregation_features *= feature_mask
            out_features = aggregation_features.sum(-1)
        else:
            raise NotImplementedError(f'Reduction {self.reduction} not implemented in PointWiseMLP')
        return out_features, trans, thisVar


    def forward_firstpapss(self, query_xyz, support_xyz, query_mask, support_mask, support_features):
        """
        Args:
            query_xyz: [B, N1, 3], query points.
            support_xyz: [B, N2, 3], support points.
            query_mask: [B, N1], mask for query points.
            support_mask: [B, N2], mask for support points.
            support_features: [B, C_in, N2], input features of support points.

        Returns:
           output features of query points: [B, C_out, 3]
        """
        neighborhood_features, relative_position, neighborhood_mask = self.grouper(query_xyz, support_xyz, query_mask,
                                                                                   support_mask, support_features)
        if self.feature_type == 'dp_fi_df':
            # B C N M
            center_features = torch.unsqueeze(neighborhood_features[..., 0], -1).repeat([1, 1, 1, self.nsample])
            relative_features = neighborhood_features - center_features

            local_input_features = torch.cat([relative_position, center_features, relative_features], 1)
            aggregation_features = self.mlps(local_input_features)
        else:
            raise NotImplementedError(f'Feature Type {self.feature_type} not implemented in PointWiseMLP')


            ###############
        # print("aggregation_features")
        # print(aggregation_features.shape)

        aggregation_features =aggregation_features.permute(0,1,3,2)

        # (B, D, npoint, nsample)
        diffFeatureNorm, nsample =  self.aggreateSGC_firstpass(aggregation_features)  ## [B, D, S]
        return diffFeatureNorm, nsample, aggregation_features, neighborhood_mask

##

    def forward_secondpapss(self, query_mask, learnTrans, diffFeatureNorm, weight, aggregation_features,neighborhood_mask):

        # (B, D, npoint, nsample)
        sgcFeature, thisVar =  self.aggreateSGC_second_pass(aggregation_features, learnTrans, diffFeatureNorm, weight)  ## [B, D, S]

################ attentive fusion
        B,D,K,S = aggregation_features.size()

        new_points_projected = self.conv1_forFusion((aggregation_features)).permute(0,3,2,1)   ## [B, S, K , D]
        sgc_projected = self.projectBack_forFusion(sgcFeature).permute(0,3,2,1)   ## [B, S, 1 , D]
        weights = torch.bmm(new_points_projected.contiguous().view(B*S,K,-1), sgc_projected.contiguous().view(B*S,1,-1).permute(0,2,1))  ## BSK1
        weights = self.tanh(weights).contiguous().view(B,S,K,1).permute(0,3,2,1).repeat(1,D,1,1)  ## B S K 1   -> B1 K S

        sgc_aggreate_feature = self.projectBack(sgcFeature) ## [B, S, 1 , D]

        aggregation_features = aggregation_features + weights* (sgc_aggreate_feature.repeat(1,1,K,1))
        aggregation_features = self.Fusion(aggregation_features)

        ################
        aggregation_features =aggregation_features.permute(0,1,3,2)


        if self.reduction == 'max':
            out_features = F.max_pool2d(
                aggregation_features, kernel_size=[1, self.nsample]
            )
            out_features = torch.squeeze(out_features, -1)
        elif self.reduction == 'avg' or self.reduction == 'mean':
            feature_mask = neighborhood_mask + (1 - query_mask[:, :, None])
            feature_mask = feature_mask[:, None, :, :]
            aggregation_features *= feature_mask
            out_features = aggregation_features.sum(-1)
            neighborhood_num = feature_mask.sum(-1)
            out_features /= neighborhood_num
        elif self.reduction == 'sum':
            feature_mask = neighborhood_mask + (1 - query_mask[:, :, None])
            feature_mask = feature_mask[:, None, :, :]
            aggregation_features *= feature_mask
            out_features = aggregation_features.sum(-1)
        else:
            raise NotImplementedError(f'Reduction {self.reduction} not implemented in PointWiseMLP')
        return out_features, thisVar



class PseudoGrid(nn.Module):
    def __init__(self, in_channels, out_channels, radius, nsample, config):
        """A PseudoGrid operator for local aggregation

        Args:
            in_channels: input channels.
            out_channels: output channels.
            radius: ball query radius
            nsample: neighborhood limit.
            config: config file
        """
        super(PseudoGrid, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.radius = radius
        self.nsample = nsample
        self.KP_influence = config.pseudo_grid.KP_influence
        self.num_kernel_points = config.pseudo_grid.num_kernel_points
        self.convolution_mode = config.pseudo_grid.convolution_mode
        self.output_conv = config.pseudo_grid.output_conv or (self.in_channels != self.out_channels)

        # create kernel points
        KP_extent = config.pseudo_grid.KP_extent
        fixed_kernel_points = config.pseudo_grid.fixed_kernel_points
        density_parameter = config.density_parameter
        self.extent = 2 * KP_extent * radius / density_parameter
        K_radius = 1.5 * self.extent
        K_points_numpy = create_kernel_points(K_radius,
                                              self.num_kernel_points,
                                              num_kernels=1,
                                              dimension=3,
                                              fixed=fixed_kernel_points)

        K_points_numpy = K_points_numpy.reshape((self.num_kernel_points, 3))
        self.register_buffer('K_points', torch.from_numpy(K_points_numpy).type(torch.float32))

        self.grouper = MaskedQueryAndGroup(radius, nsample, use_xyz=False, ret_grouped_xyz=True, normalize_xyz=False)
        self.kernel_weights = weight_variable([self.num_kernel_points, in_channels])

        if self.output_conv:
            self.out_conv = nn.Sequential(
                nn.Conv1d(in_channels, out_channels, kernel_size=1, bias=False),
                nn.BatchNorm1d(out_channels, momentum=config.bn_momentum),
                nn.ReLU(inplace=True))
        else:
            self.out_transform = nn.Sequential(
                nn.BatchNorm1d(out_channels, momentum=config.bn_momentum),
                nn.ReLU(inplace=True))

    def forward(self, query_xyz, support_xyz, query_mask, support_mask, support_features):
        """
        Args:
            query_xyz: [B, N1, 3], query points.
            support_xyz: [B, N2, 3], support points.
            query_mask: [B, N1], mask for query points.
            support_mask: [B, N2], mask for support points.
            support_features: [B, C_in, N2], input features of support points.

        Returns:
           output features of query points: [B, C_out, 3]
        """
        B = query_xyz.shape[0]
        C = support_features.shape[1]
        npoint = query_xyz.shape[1]
        neighborhood_features, relative_position, neighborhood_mask = self.grouper(query_xyz, support_xyz, query_mask,
                                                                                   support_mask, support_features)
        relative_position = torch.unsqueeze(relative_position.permute(0, 2, 3, 1), 3)
        relative_position = relative_position.repeat([1, 1, 1, self.num_kernel_points, 1])

        # Get Kernel point influences [B, N, K, M]
        differences = relative_position - self.K_points
        sq_distances = torch.sum(differences ** 2, -1)
        if self.KP_influence == 'constant':
            # Every point get an influence of 1.
            all_weights = torch.ones_like(sq_distances)
            all_weights = all_weights.permute(0, 1, 3, 2)
        elif self.KP_influence == 'linear':
            # Influence decrease linearly with the distance, and get to zero when d = KP_extent.
            all_weights = torch.clamp(1 - torch.sqrt(sq_distances) / self.extent, min=0.0)
            all_weights = all_weights.permute(0, 1, 3, 2)
        elif self.KP_influence == 'gaussian':
            # Influence in gaussian of the distance.
            sigma = self.extent * 0.3
            all_weights = radius_gaussian(sq_distances, sigma)
            all_weights = all_weights.permute(0, 1, 3, 2)
        else:
            raise ValueError('Unknown influence function type (config.KP_influence)')

        # Mask padding points
        feature_mask = neighborhood_mask + (1 - query_mask[:, :, None])  # B, N, M
        all_weights *= feature_mask[:, :, None, :]  # B, N, K, M

        if self.convolution_mode != 'sum':
            raise NotImplementedError(f"convolution_mode:{self.convolution_mode} not support in PseudoGrid")

        # get features for each kernel point
        all_weights = all_weights.view(-1, self.num_kernel_points, self.nsample)
        neighborhood_features = neighborhood_features.permute(0, 2, 3, 1).contiguous().view(-1, self.nsample, C)
        weighted_features = torch.bmm(all_weights, neighborhood_features)  # # [B*N, K, M],[B*N, M, C] -> [B*N, K, C]
        kernel_outputs = weighted_features * self.kernel_weights  # [B*N, K, C]
        out_features = torch.sum(kernel_outputs, 1).view(B, npoint, C).transpose(1, 2)

        if self.output_conv:
            out_features = self.out_conv(out_features)
        else:
            out_features = self.out_transform(out_features)

        return out_features

class PseudoGrid_LRF(nn.Module):
    def __init__(self, in_channels, out_channels, radius, nsample, config, trans):
        """A PseudoGrid operator for local aggregation
        Args:
            in_channels: input channels.
            out_channels: output channels.
            radius: ball query radius
            nsample: neighborhood limit.
            config: config file
        """
        super(PseudoGrid_LRF, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.radius = radius
        self.nsample = nsample
        self.KP_influence = config.pseudo_grid.KP_influence
        self.num_kernel_points = config.pseudo_grid.num_kernel_points
        self.convolution_mode = config.pseudo_grid.convolution_mode
        self.output_conv = config.pseudo_grid.output_conv or (self.in_channels != self.out_channels)

        # create kernel points
        KP_extent = config.pseudo_grid.KP_extent
        fixed_kernel_points = config.pseudo_grid.fixed_kernel_points
        density_parameter = config.density_parameter
        self.extent = 2 * KP_extent * radius / density_parameter
        K_radius = 1.5 * self.extent
        K_points_numpy = create_kernel_points(K_radius,
                                              self.num_kernel_points,
                                              num_kernels=1,
                                              dimension=3,
                                              fixed=fixed_kernel_points)

        K_points_numpy = K_points_numpy.reshape((self.num_kernel_points, 3))
        self.register_buffer('K_points', torch.from_numpy(K_points_numpy).type(torch.float32))

        self.grouper = MaskedQueryAndGroup(radius, nsample, use_xyz=False, ret_grouped_xyz=True, normalize_xyz=False)
        self.kernel_weights = weight_variable([self.num_kernel_points, in_channels])

        if self.output_conv:
            self.out_conv = nn.Sequential(
                nn.Conv1d(in_channels, out_channels, kernel_size=1, bias=False),
                nn.BatchNorm1d(out_channels, momentum=config.bn_momentum),
                nn.ReLU(inplace=True))
        else:
            self.out_transform = nn.Sequential(
                nn.BatchNorm1d(out_channels, momentum=config.bn_momentum),
                nn.ReLU(inplace=True))


        temp_channels = in_channels+3
        self.voxel=8.0
        self.bottleneck_channel = max(32,in_channels//2)
        self.projectFrom= nn.Sequential(
                                             nn.Conv2d(temp_channels, int(temp_channels*0.5), 1),
                                             nn.BatchNorm2d(int(temp_channels*0.5)),
                                             nn.ReLU(),
                                             nn.Conv2d(int(temp_channels*0.5), 3, 1),
                                             nn.BatchNorm2d(3),
                                             nn.ReLU())

        self.conv1_forFusion= nn.Sequential(
                                             nn.Conv2d(temp_channels, self.bottleneck_channel, 1),
                                             nn.BatchNorm2d(self.bottleneck_channel))

        self.projectBack_forFusion= nn.Sequential(
                                             nn.Conv2d(int(3*self.voxel*self.voxel*self.voxel),  self.bottleneck_channel,1),)
                                             # nn.BatchNorm2d( self.bottleneck_channel))

        self.projectBack= nn.Sequential(
                                             nn.Conv2d(int(3*self.voxel*self.voxel*self.voxel),  temp_channels, 1),
                                             nn.BatchNorm2d(temp_channels),
                                             nn.ReLU())

        self.Fusion= nn.Sequential(
                                             nn.Conv2d(temp_channels, temp_channels, 1),
                                             nn.BatchNorm2d(temp_channels),
                                             nn.ReLU(),
                                             nn.Conv2d(temp_channels,temp_channels, 1),
                                             nn.BatchNorm2d(temp_channels),
                                             nn.ReLU())

        self.T =trans
        self.siz=torch.Tensor([2.0001/self.voxel,2.0001/self.voxel,2.0001/self.voxel])
        self.star  =torch.Tensor([-1.0,-1.0,-1.0])
        self.end  =torch.Tensor([1.0,1.0,1.0])
        self.tanh = torch.nn.Sequential(nn.Sigmoid())


    def computeSGCDirect(self, pos, BN, M,C,siz,star,end):    ##pos : {B*N*M, C}

            cluster_inds = grid_cluster(pos, siz,start=star,end=end)             ##: {B*N*M}
            cluster_gather = []

            for ii in range(C):
                cluster_gather.append(cluster_inds.unsqueeze(1)*C+ii)

            cluster_inds = torch.cat(cluster_gather,dim=1).view(-1)   ## 100,  32

            final_inds = torch.linspace(0, (BN-1)*int(pow(self.voxel,C))*C, BN).unsqueeze(1).repeat(1, M*C).view(-1).cuda()    ##: {B*N*M*C}
            final_inds += cluster_inds

            reduced_pos = (pos).view(BN*M*C)          #{B*N, M*C}
            reduced_Num = torch.ones(BN*M*C).cuda()

            finResult = torch.zeros(BN,int(pow(self.voxel,C))*C).cuda()             ##    B*N ,voxel^3 ,3
            finResult_Num = torch.zeros(BN,int(pow(self.voxel,C))*C).cuda()   ##    B*N ,voxel^3 ,3
            # reduced_Num = torch.cuda.FloatTensor(BN*M*C).fill_(1.0) #  torch.ones(BN*M*C).cuda()
            #
            # finResult =  torch.cuda.FloatTensor(BN,int(pow(voxel,C))*C).fill_(0.0)   #torch.zeros(BN,int(pow(voxel,C))*C).cuda()             ##    B*N ,voxel^3 ,3
            # finResult_Num = torch.cuda.FloatTensor(BN,int(pow(voxel,C))*C).fill_(0.0) #torch.zeros(BN,int(pow(voxel,C))*C).cuda()   ##    B*N ,voxel^3 ,3


            finResult.put_(final_inds.long(), reduced_pos, accumulate=True)
            finResult_Num.put_(final_inds.long(), reduced_Num, accumulate=True)

            finResult = finResult/(finResult_Num+1.0e-6)

        ###B*N*Featuresize
            return finResult

    def compueSGC(self, grouped_points):   ## input [B,  S, K , D]
         # print("before")
         # print(grouped_points.shape)

         if (torch.isnan(grouped_points.contiguous().view(-1)).sum().item()!=0):
             print("input in compute sgc has nan")
         grouped_points = grouped_points
         B,S,K,D = grouped_points.size()
         groups_mean = grouped_points.mean(2, keepdim=True).repeat(1,1,K, 1)

         diffFeature = grouped_points-groups_mean
         diffFeature = diffFeature.contiguous().view(-1, K, D)  # [B*S, K, D]

         diffFeatureNorm = diffFeature

         # print("diff feature")
         # print(diffFeatureNorm.shape)
         # print('\n')

         learnTrans, weight = self.T(diffFeatureNorm.permute(0,2,1),self.nsample)  ##input B,3,N
         projectedDiffFeature = torch.bmm(learnTrans, diffFeatureNorm.permute(0,2,1)).permute(0,2,1)   ##B,N,3-> B x 3 x N,  -> B,N,3

         # print("before\n")
         # print(projectedDiffFeature.max())
         # print(projectedDiffFeature.min())

         max_length=torch.max(torch.norm(projectedDiffFeature,dim=2,p=2),dim=1)[0]+0.00001
         projectedDiffFeature = projectedDiffFeature/max_length.unsqueeze(-1).unsqueeze(-1)

         B1, M1, C1 = projectedDiffFeature.size()

         siz =self.siz.cuda()
         star =self.star.cuda()
         end =self.end.cuda()

         sgc_feature = self.computeSGCDirect(projectedDiffFeature.contiguous().view(-1,C1),B1,M1, 3, siz, star, end)
         sgc_feature_forCalc = sgc_feature%(1.0/self.voxel)

         sgc_feature = sgc_feature.contiguous().view(B,S,-1)   ### B1, voxel*voxel*voxel

         xx=torch.sum(sgc_feature_forCalc,dim=0)+1.0e-6
         sgc_var = -1.0* xx*torch.log(xx)
         sgc_var =  torch.sum(sgc_var)  #torch.mean(torch.var(sgc_feature_forCalc,dim=-1))
         # torch.clamp(torch.nn.functional.relu(torch.var(projectedDiffFeature,dim=-1)- self.thres),min=0.0,max=1.0)
         return sgc_feature,learnTrans, weight, sgc_var #torch.clamp(torch.nn.functional.relu(torch.var(projectedDiffFeature,dim=-1)- self.thres),min=0.0,max=1.0)

    def aggreateSGC(self, grouped_points):   # [B, D, K, S]
             B,D,K,S = grouped_points.size()

             features = self.projectFrom(grouped_points).permute(0,3,2,1) # [BSKD]
             features, trans, weight, thisVar = self.compueSGC(features)     # [B, S, D']

             features = features.contiguous().view(B*S,-1)
             features = features*weight
             features = features.contiguous().view(B,S,-1).transpose(1, 2).unsqueeze(2)

             return  features, trans, thisVar

    def forward(self, query_xyz, support_xyz, query_mask, support_mask, support_features):
        """
        Args:
            query_xyz: [B, N1, 3], query points.
            support_xyz: [B, N2, 3], support points.
            query_mask: [B, N1], mask for query points.
            support_mask: [B, N2], mask for support points.
            support_features: [B, C_in, N2], input features of support points.

        Returns:
           output features of query points: [B, C_out, 3]
        """
        B = query_xyz.shape[0]
        C = support_features.shape[1]
        npoint = query_xyz.shape[1]
        neighborhood_features, relative_position, neighborhood_mask = self.grouper(query_xyz, support_xyz, query_mask,
                                                                                   support_mask, support_features)

        ############################################
        ##(B, C + 3, npoint, nsample)
        aggregation_features =neighborhood_features.permute(0,1,3,2)

        # (B, D, npoint, nsample)
        sgcFeature, trans, thisVar =  self.aggreateSGC(aggregation_features)  ## [B, D, S]

################ attentive fusion
        B,D,K,S = aggregation_features.size()

        new_points_projected = self.conv1_forFusion((aggregation_features)).permute(0,3,2,1)   ## [B, S, K , D]
        sgc_projected = self.projectBack_forFusion(sgcFeature).permute(0,3,2,1)   ## [B, S, 1 , D]
        weights = torch.bmm(new_points_projected.contiguous().view(B*S,K,-1), sgc_projected.contiguous().view(B*S,1,-1).permute(0,2,1))  ## BSK1
        weights = self.tanh(weights).contiguous().view(B,S,K,1).permute(0,3,2,1).repeat(1,D,1,1)  ## B S K 1   -> B1 K S

        sgc_aggreate_feature = self.projectBack(sgcFeature) ## [B, S, 1 , D]

        aggregation_features = aggregation_features + weights* (sgc_aggreate_feature.repeat(1,1,K,1))
        aggregation_features = self.Fusion(aggregation_features)

        ################
        neighborhood_features =aggregation_features.permute(0,1,3,2)

        ############################################

        relative_position = torch.unsqueeze(relative_position.permute(0, 2, 3, 1), 3)
        relative_position = relative_position.repeat([1, 1, 1, self.num_kernel_points, 1])

        # Get Kernel point influences [B, N, K, M]
        differences = relative_position - self.K_points
        sq_distances = torch.sum(differences ** 2, -1)
        if self.KP_influence == 'constant':
            # Every point get an influence of 1.
            all_weights = torch.ones_like(sq_distances)
            all_weights = all_weights.permute(0, 1, 3, 2)
        elif self.KP_influence == 'linear':
            # Influence decrease linearly with the distance, and get to zero when d = KP_extent.
            all_weights = torch.clamp(1 - torch.sqrt(sq_distances) / self.extent, min=0.0)
            all_weights = all_weights.permute(0, 1, 3, 2)
        elif self.KP_influence == 'gaussian':
            # Influence in gaussian of the distance.
            sigma = self.extent * 0.3
            all_weights = radius_gaussian(sq_distances, sigma)
            all_weights = all_weights.permute(0, 1, 3, 2)
        else:
            raise ValueError('Unknown influence function type (config.KP_influence)')

        # Mask padding points
        feature_mask = neighborhood_mask + (1 - query_mask[:, :, None])  # B, N, M
        all_weights *= feature_mask[:, :, None, :]  # B, N, K, M

        if self.convolution_mode != 'sum':
            raise NotImplementedError(f"convolution_mode:{self.convolution_mode} not support in PseudoGrid")

        # get features for each kernel point
        all_weights = all_weights.view(-1, self.num_kernel_points, self.nsample)
        neighborhood_features = neighborhood_features.permute(0, 2, 3, 1).contiguous().view(-1, self.nsample, C)
        weighted_features = torch.bmm(all_weights, neighborhood_features)  # # [B*N, K, M],[B*N, M, C] -> [B*N, K, C]
        kernel_outputs = weighted_features * self.kernel_weights  # [B*N, K, C]
        out_features = torch.sum(kernel_outputs, 1).view(B, npoint, C).transpose(1, 2)

        if self.output_conv:
            out_features = self.out_conv(out_features)
        else:
            out_features = self.out_transform(out_features)

        return out_features


class LocalAggregation(nn.Module):
    def __init__(self, in_channels, out_channels, radius, nsample, config, trans):
        """LocalAggregation operators

        Args:
            in_channels: input channels.
            out_channels: output channels.
            radius: ball query radius
            nsample: neighborhood limit.
            config: config file
        """
        super(LocalAggregation, self).__init__()
        if config.local_aggregation_type == 'pospool':
            self.local_aggregation_operator = PosPool(in_channels, out_channels, radius, nsample, config)
        elif config.local_aggregation_type == 'pospool_lrf':
            self.local_aggregation_operator = PosPool_LRF(in_channels, out_channels, radius, nsample, config,trans)
        elif config.local_aggregation_type == 'adaptive_weight':
            self.local_aggregation_operator = AdaptiveWeight(in_channels, out_channels, radius, nsample, config)
        elif config.local_aggregation_type == 'adaptive_weight_lrf':
            self.local_aggregation_operator = AdaptiveWeight_LRF(in_channels, out_channels, radius, nsample, config,trans)
        elif config.local_aggregation_type == 'pointwisemlp':
            self.local_aggregation_operator = PointWiseMLP(in_channels, out_channels, radius, nsample, config)
        elif config.local_aggregation_type == 'pointwisemlp_lrf':
            self.local_aggregation_operator = PointWiseMLP_WithLRF(in_channels, out_channels, radius, nsample, config,trans)
        elif config.local_aggregation_type == 'pseudo_grid':
            self.local_aggregation_operator = PseudoGrid(in_channels, out_channels, radius, nsample, config)
        elif config.local_aggregation_type == 'pseudo_grid_lrf':
            self.local_aggregation_operator = PseudoGrid_LRF(in_channels, out_channels, radius, nsample, config,trans)
        else:
            raise NotImplementedError(f'LocalAggregation {config.local_aggregation_type} not implemented')

    def forward(self, query_xyz, support_xyz, query_mask, support_mask, support_features):
        """
        Args:
            query_xyz: [B, N1, 3], query points.
            support_xyz: [B, N2, 3], support points.
            query_mask: [B, N1], mask for query points.
            support_mask: [B, N2], mask for support points.
            support_features: [B, C_in, N2], input features of support points.

        Returns:
           output features of query points: [B, C_out, 3]
        """
        return self.local_aggregation_operator(query_xyz, support_xyz, query_mask, support_mask, support_features)

class LocalAggregation_Ori(nn.Module):
    def __init__(self, in_channels, out_channels, radius, nsample, config):
        """LocalAggregation operators

        Args:
            in_channels: input channels.
            out_channels: output channels.
            radius: ball query radius
            nsample: neighborhood limit.
            config: config file
        """
        super(LocalAggregation_Ori, self).__init__()
        if config.local_aggregation_type == 'pospool':
            self.local_aggregation_operator = PosPool(in_channels, out_channels, radius, nsample, config)
        elif config.local_aggregation_type == 'pospool_lrf':
            self.local_aggregation_operator = PosPool(in_channels, out_channels, radius, nsample, config)
        elif config.local_aggregation_type == 'adaptive_weight':
            self.local_aggregation_operator = AdaptiveWeight(in_channels, out_channels, radius, nsample, config)
        elif config.local_aggregation_type == 'adaptive_weight_lrf':
            self.local_aggregation_operator = AdaptiveWeight(in_channels, out_channels, radius, nsample, config)
        elif config.local_aggregation_type == 'pointwisemlp':
            self.local_aggregation_operator = PointWiseMLP(in_channels, out_channels, radius, nsample, config)
        elif config.local_aggregation_type == 'pointwisemlp_lrf':
            self.local_aggregation_operator = PointWiseMLP(in_channels, out_channels, radius, nsample, config)
        elif config.local_aggregation_type == 'pseudo_grid':
            self.local_aggregation_operator = PseudoGrid(in_channels, out_channels, radius, nsample, config)
        elif config.local_aggregation_type == 'pseudo_grid_lrf':
            self.local_aggregation_operator = PseudoGrid(in_channels, out_channels, radius, nsample, config)
        else:
            raise NotImplementedError(f'LocalAggregation {config.local_aggregation_type} not implemented')

    def forward(self, query_xyz, support_xyz, query_mask, support_mask, support_features):
        """
        Args:
            query_xyz: [B, N1, 3], query points.
            support_xyz: [B, N2, 3], support points.
            query_mask: [B, N1], mask for query points.
            support_mask: [B, N2], mask for support points.
            support_features: [B, C_in, N2], input features of support points.

        Returns:
           output features of query points: [B, C_out, 3]
        """
        return self.local_aggregation_operator(query_xyz, support_xyz, query_mask, support_mask, support_features)
