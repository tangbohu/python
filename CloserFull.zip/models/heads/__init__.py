from .classifier import ClassifierResNet
from .segmentation_head import MultiPartSegHeadResNet, SceneSegHeadResNet
